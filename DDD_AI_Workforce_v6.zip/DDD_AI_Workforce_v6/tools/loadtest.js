#!/usr/bin/env node
'use strict';
/**
 * Workday load test — simulates the 08:00 rush of an entire workforce.
 *
 *   node tools/loadtest.js [--url=http://localhost:8765] [--users=550]
 *                          [--admin=ADM-001] [--admin-pass=admin123] [--cleanup]
 *
 * Phases (all users concurrently):
 *   1. provision N test accounts (LT-0001…)          — admin API, seat capacity enforced
 *   2. login storm                                    — scrypt under load
 *   3. open N WebSockets + register                   — live presence
 *   4. clock-in, dashboard, chat, take break, resume  — the busiest real flows
 *   5. 30 s of heartbeats while a supervisor polls the live monitor
 * Reports p50 / p95 / p99 / max latency and error counts per phase.
 */
const WebSocket = require('ws');

const arg = (k, d) => { const a = process.argv.find(x => x.startsWith(`--${k}=`)); return a ? a.split('=').slice(1).join('=') : d; };
const URL_ = arg('url', 'http://localhost:8765').replace(/\/+$/, '');
const N = parseInt(arg('users', '550'), 10);
const ADMIN = arg('admin', 'ADM-001'), ADMIN_PASS = arg('admin-pass', 'admin123');
const DEV = arg('dev', 'DEV-001'), DEV_PASS = arg('dev-pass', 'DDD@SuperDev2026!');
const CLEANUP = process.argv.includes('--cleanup');
const PASS = 'LoadTest2026';
const QUESTIONS = ['how many leave days do I get', 'what time does my shift start', 'how long is lunch', 'is overtime paid more on weekends',
  'nataka likizo siku ngapi', 'saa za kazi ni zipi', 'I forgot my password', 'what about maternity leave', 'when is salary paid', 'sha deductions'];

const stats = {};
function record(phase, ms, ok) {
  const s = stats[phase] || (stats[phase] = { t: [], err: 0 });
  s.t.push(ms); if (!ok) s.err++;
}
async function req(phase, method, path, body, token) {
  const t0 = performance.now();
  try {
    const r = await fetch(URL_ + path, { method, headers: { 'content-type': 'application/json', ...(token ? { 'x-ddd-session': token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const text = await r.text();
    record(phase, performance.now() - t0, r.ok);
    try { return { status: r.status, data: JSON.parse(text) }; } catch (_) { return { status: r.status, data: text }; }
  } catch (e) { record(phase, performance.now() - t0, false); return { status: 0, data: { error: e.message } }; }
}
const pct = (arr, p) => { const a = [...arr].sort((x, y) => x - y); return a.length ? a[Math.min(a.length - 1, Math.floor(p / 100 * a.length))] : 0; };
function report() {
  console.log('\n  Phase                 count   p50 ms   p95 ms   p99 ms   max ms   errors');
  console.log('  ' + '─'.repeat(76));
  for (const [k, s] of Object.entries(stats)) {
    console.log(`  ${k.padEnd(20)} ${String(s.t.length).padStart(6)} ${pct(s.t, 50).toFixed(0).padStart(8)} ${pct(s.t, 95).toFixed(0).padStart(8)} ${pct(s.t, 99).toFixed(0).padStart(8)} ${Math.max(...s.t).toFixed(0).padStart(8)} ${String(s.err).padStart(8)}`);
  }
}
const ids = Array.from({ length: N }, (_, i) => `LT-${String(i + 1).padStart(4, '0')}`);

(async () => {
  console.log(`\n  DDD load test → ${URL_}  (${N} employees)\n`);
  const admin = await req('admin-login', 'POST', '/api/login', { user_id: ADMIN, password: ADMIN_PASS });
  if (!admin.data.token) { console.error('  Admin login failed:', admin.data); process.exit(1); }
  const AT = admin.data.token;

  let t = Date.now();
  const existing = new Set(((await req('list-users', 'GET', '/api/users?q=LT-&limit=2000', null, AT)).data.items || []).map(u => u.id));
  const results = await Promise.all(ids.filter(id => !existing.has(id)).map((id, i) =>
    req('1 provision', 'POST', '/api/users', { id, name: `Load Tester ${i + 1}`, email: `${id.toLowerCase()}@loadtest.local`, department: ['Production', 'Quality', 'Operations'][i % 3], role: 'Employee', password: PASS }, AT)));
  const capped = results.filter(r => r.status === 409).length;
  console.log(`  1. provisioned ${results.filter(r => r.status === 200).length} (+${existing.size} existing)${capped ? `, ${capped} refused by seat capacity` : ''} in ${Date.now() - t} ms`);

  t = Date.now();
  const logins = await Promise.all(ids.map(id => req('2 login', 'POST', '/api/login', { user_id: id, password: PASS })));
  const tokens = logins.map(l => l.data && l.data.token).filter(Boolean);
  console.log(`  2. login storm: ${tokens.length}/${N} signed in in ${Date.now() - t} ms`);

  t = Date.now();
  const wsUrl = URL_.replace(/^http/, 'ws') + '/ws';
  const sockets = await Promise.all(tokens.map(tok => new Promise(resolve => {
    const t0 = performance.now();
    const ws = new WebSocket(wsUrl, { headers: { origin: URL_ } });
    let settled = false;
    const done = (ok) => { if (settled) return; settled = true; record('3 ws register', performance.now() - t0, ok); resolve(ok ? ws : null); };
    ws.on('open', () => ws.send(JSON.stringify({ type: 'REGISTER', token: tok })));
    ws.on('message', (m) => { if (JSON.parse(m).type === 'REGISTERED') done(true); });
    ws.on('error', () => done(false));
    setTimeout(() => done(false), 15000);
  })));
  const live = sockets.filter(Boolean);
  console.log(`  3. WebSockets: ${live.length}/${tokens.length} registered in ${Date.now() - t} ms`);

  t = Date.now();
  await Promise.all(tokens.map(async (tok, i) => {
    await req('4a clock-in', 'POST', '/api/start', null, tok);
    await req('4b dashboard', 'GET', '/api/dashboard', null, tok);
    await req('4c chat', 'POST', '/api/chat', { message: QUESTIONS[i % QUESTIONS.length] }, tok);
    await req('4d break', 'POST', '/api/break', null, tok);
    await req('4e resume', 'POST', '/api/resume', null, tok);
  }));
  console.log(`  4. workday flows (5 requests × ${tokens.length}) in ${Date.now() - t} ms`);

  const sup = await req('admin-login', 'POST', '/api/login', { user_id: 'SUP-101', password: 'supervisor123' });
  const ST = sup.data.token || AT;
  const hb = setInterval(() => live.forEach(ws => ws.readyState === 1 && ws.send(JSON.stringify({ type: 'HEARTBEAT', status: 'WORKING', idleMs: 5000 }))), 5000);
  const poll = setInterval(() => { req('5 monitor poll', 'GET', '/api/online', null, ST); req('5 sup dashboard', 'GET', '/api/dashboard', null, ST); }, 1000);
  await new Promise(r => setTimeout(r, 30000));
  clearInterval(hb); clearInterval(poll);
  const online = (await req('5 monitor poll', 'GET', '/api/online', null, ST)).data.items || [];
  console.log(`  5. sustained 30 s: monitor sees ${online.filter(u => u.id.startsWith('LT-')).length} load-test employees online`);

  const dev = await req('admin-login', 'POST', '/api/login', { user_id: DEV, password: DEV_PASS });
  const health = dev.data.token ? (await req('system', 'GET', '/api/system', null, dev.data.token)).data : null;
  report();
  if (health && health.memory) console.log(`\n  Server memory: RSS ${(health.memory.rss / 1048576).toFixed(0)} MB, heap ${(health.memory.heapUsed / 1048576).toFixed(0)} MB (single Node process)`);
  live.forEach(ws => ws.close());

  await Promise.all(tokens.map(tok => req('cleanup stop', 'POST', '/api/stop', null, tok)));
  if (CLEANUP) {
    let removed = 0;
    for (const id of ids) { const r = await req('cleanup', 'DELETE', `/api/users/${id}`, { reason: 'load test cleanup' }, AT); if (r.status === 200) removed++; }
    console.log(`  Cleanup: removed ${removed} load-test accounts (dossiers archived as usual).`);
  } else console.log('  Test accounts kept (LT-xxxx). Re-run with --cleanup to remove them.');
  const errs = Object.values(stats).reduce((s, x) => s + x.err, 0);
  console.log(errs ? `\n  ⚠ ${errs} errors — see table above.\n` : '\n  ✓ No errors.\n');
  process.exit(errs ? 1 : 0);
})();
