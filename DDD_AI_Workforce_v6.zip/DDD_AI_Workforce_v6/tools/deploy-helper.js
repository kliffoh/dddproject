#!/usr/bin/env node
'use strict';
/**
 * Cross-platform deployment helper.
 * DDD_HOSTING.bat (Windows) and DDD_HOSTING.sh (Linux/macOS) both call this,
 * so every hosting option behaves identically on every OS.
 *
 *   node tools/deploy-helper.js env-set KEY=VALUE [KEY=VALUE…]
 *   node tools/deploy-helper.js env-get KEY
 *   node tools/deploy-helper.js caddyfile <domain> <email>
 *   node tools/deploy-helper.js dns-check <domain>
 *   node tools/deploy-helper.js netlify-build <backend-url>
 *   node tools/deploy-helper.js fly-toml <app-name> [region]
 *   node tools/deploy-helper.js health [url]
 *   node tools/deploy-helper.js data-dir
 */
const fs = require('fs');
const path = require('path');
const dns = require('dns').promises;

const ROOT = path.resolve(__dirname, '..');
const ENV = path.join(ROOT, '.env');
const GEN = path.join(ROOT, 'deploy', 'generated');
const ok = (m) => console.log(`  [OK]  ${m}`);
const warn = (m) => console.log(`  [!]   ${m}`);
const die = (m) => { console.error(`  [ERROR] ${m}`); process.exit(1); };

function readEnv() {
  if (!fs.existsSync(ENV)) fs.copyFileSync(path.join(ROOT, '.env.example'), ENV);
  return fs.readFileSync(ENV, 'utf8');
}
function envGet(key) {
  const m = readEnv().match(new RegExp(`^${key}=(.*)$`, 'm'));
  return m ? m[1].trim() : '';
}
function envSet(pairs) {
  let text = readEnv();
  for (const pair of pairs) {
    const i = pair.indexOf('=');
    if (i < 1) die(`Bad pair: ${pair}`);
    const k = pair.slice(0, i), v = pair.slice(i + 1).replace(/[\r\n]/g, '');
    const re = new RegExp(`^${k}=.*$`, 'm');
    text = re.test(text) ? text.replace(re, `${k}=${v}`) : `${text.replace(/\s*$/, '')}\n${k}=${v}\n`;
    ok(`.env  ${k}=${/PASS|KEY|TOKEN/.test(k) && v ? '********' : v}`);
  }
  fs.writeFileSync(ENV, text);
}
const DOMAIN_RE = /^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;

function defaultDataDir() {
  return envGet('DDD_DATA_DIR') || path.join(process.env.APPDATA || process.env.HOME || ROOT, 'DDD_WorkforceSystem');
}

async function publicIp() {
  try { const r = await fetch('https://api.ipify.org', { signal: AbortSignal.timeout(6000) }); return (await r.text()).trim(); }
  catch (_) { return null; }
}

const commands = {
  'env-set': (...pairs) => envSet(pairs),
  'env-get': (key) => console.log(envGet(key)),
  'data-dir': () => console.log(defaultDataDir()),

  caddyfile(domain, email) {
    if (!DOMAIN_RE.test(domain || '')) die('Enter a valid domain like workforce.example.com');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email || '')) die('Enter a valid email (used for Let\'s Encrypt expiry notices).');
    const port = envGet('PORT') || '8765';
    const tpl = fs.readFileSync(path.join(ROOT, 'deploy', 'Caddyfile.template'), 'utf8');
    fs.mkdirSync(GEN, { recursive: true });
    const out = path.join(GEN, 'Caddyfile');
    fs.writeFileSync(out, tpl.replace(/\{\$DOMAIN\}/g, domain).replace(/\{\$EMAIL\}/g, email).replace(/\{\$UPSTREAM\}/g, `127.0.0.1:${port}`));
    ok(`Caddyfile written: ${out}`);
    envSet([`PUBLIC_URL=https://${domain}`, 'TRUST_PROXY=1', `DDD_DATA_DIR=${defaultDataDir()}`]);
  },

  async 'dns-check'(domain) {
    if (!DOMAIN_RE.test(domain || '')) die('Invalid domain.');
    const [ip, records] = await Promise.all([publicIp(), dns.resolve4(domain).catch(() => [])]);
    console.log(`  This machine's public IP : ${ip || '(could not detect)'}`);
    console.log(`  ${domain} resolves to    : ${records.join(', ') || '(no A record yet)'}`);
    if (!records.length) { warn(`Create an A record:  ${domain}  →  ${ip || 'your public IP'}  at your DNS provider, then wait a few minutes.`); process.exit(2); }
    if (ip && !records.includes(ip)) { warn('DNS points elsewhere. If you use Cloudflare\'s orange-cloud proxy this is expected; otherwise fix the A record.'); process.exit(3); }
    ok('DNS is pointing at this machine.');
  },

  'netlify-build'(backend) {
    let url;
    try { url = new URL(backend); } catch (_) { die('Enter the full backend URL, e.g. https://workforce.example.com'); }
    if (url.protocol !== 'https:') warn('Netlify serves HTTPS, so the backend must be HTTPS too (browsers block mixed content).');
    const origin = url.origin;
    const dist = path.join(ROOT, 'deploy', 'netlify', 'dist');
    fs.rmSync(dist, { recursive: true, force: true });
    fs.mkdirSync(dist, { recursive: true });
    fs.copyFileSync(path.join(ROOT, 'public', 'index.html'), path.join(dist, 'index.html'));
    fs.writeFileSync(path.join(dist, 'config.js'), `window.DDD_CONFIG = { apiBase: '${origin}' };\n`);
    const wsOrigin = origin.replace(/^http/, 'ws');
    fs.writeFileSync(path.join(dist, '_headers'), `/*
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob:; connect-src 'self' ${origin} ${wsOrigin}; frame-ancestors 'none'
/config.js
  Cache-Control: no-cache
/index.html
  Cache-Control: no-cache
`);
    fs.copyFileSync(path.join(ROOT, 'deploy', 'netlify', 'netlify.toml'), path.join(dist, 'netlify.toml'));
    ok(`Netlify bundle ready: ${dist}`);
    ok(`It will call the backend at ${origin} (API + WebSocket go there directly).`);
  },

  'fly-toml'(app, region = 'jnb') {
    if (!/^[a-z0-9-]{3,40}$/.test(app || '')) die('App name: 3-40 lowercase letters, digits, dashes.');
    const tpl = fs.readFileSync(path.join(ROOT, 'deploy', 'fly.toml.template'), 'utf8');
    fs.writeFileSync(path.join(ROOT, 'fly.toml'), tpl.replace(/\{\$APP\}/g, app).replace(/\{\$REGION\}/g, region));
    ok(`fly.toml written for app "${app}" in region "${region}"`);
  },

  async health(url) {
    const base = (url || `http://localhost:${envGet('PORT') || 8765}`).replace(/\/+$/, '');
    try {
      const r = await fetch(`${base}/api/health`, { signal: AbortSignal.timeout(6000) });
      const d = await r.json();
      ok(`${base} is UP — v${d.version}, ${d.online} online, ${d.eat}`);
    } catch (e) { warn(`${base} is not responding (${e.cause?.code || e.message}).`); process.exit(1); }
  }
};

const [cmd, ...args] = process.argv.slice(2);
if (!commands[cmd]) { console.log(fs.readFileSync(__filename, 'utf8').split('\n').slice(3, 18).join('\n')); process.exit(cmd ? 1 : 0); }
Promise.resolve(commands[cmd](...args)).catch(e => die(e.message));
