#!/usr/bin/env node
'use strict';
/**
 * Bulk-onboard employees from a CSV file (safe to run while the server is up —
 * SQLite WAL + busy_timeout handle the concurrent writer).
 *
 *   node tools/import-employees.js employees.csv [--password=Initial123]
 *
 * Columns: id,name,email,department,role,job_title,phone,birthday,hire_date
 * Existing IDs/emails are skipped (never overwritten). Seat capacity is enforced.
 * Generated passwords are written ONCE to <file>_credentials.csv — distribute
 * them, then delete that file.
 */
process.removeAllListeners('warning');
const fs = require('fs');
const path = require('path');
const config = require('../src/config');
for (const d of Object.values(config.dirs)) fs.mkdirSync(d, { recursive: true });
const db = require('../src/db/database');
const { migrate } = require('../src/db/migrations');
const { initials, tracking } = require('../src/db/seed');
const password = require('../src/security/password');
const { now } = require('../src/core/time');
const { ID_RE } = require('../src/core/http-error');

function parseCsv(text) {
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (c === '"') q = false; else cell += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows.filter(r => r.some(x => x.trim()));
}

(async () => {
  const file = process.argv[2];
  const fixed = (process.argv.find(a => a.startsWith('--password=')) || '').split('=')[1];
  if (!file || !fs.existsSync(file)) { console.error('Usage: node tools/import-employees.js employees.csv [--password=Initial123]'); process.exit(1); }
  if (fixed && password.policy(fixed)) { console.error(password.policy(fixed)); process.exit(1); }
  migrate();
  const [header, ...rows] = parseCsv(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
  const cols = header.map(h => h.trim().toLowerCase());
  const get = (r, k) => (r[cols.indexOf(k)] || '').trim();
  for (const req of ['id', 'name', 'email', 'department']) if (!cols.includes(req)) { console.error(`Missing column: ${req}`); process.exit(1); }

  const ROLES = ['Employee', 'Supervisor', 'Manager', 'Admin'];
  let active = db.get('SELECT COUNT(*) AS c FROM employees WHERE active=1').c;
  const creds = [['id', 'name', 'password']];
  let added = 0, skipped = 0;
  for (const [n, r] of rows.entries()) {
    const line = n + 2;
    const id = get(r, 'id').toUpperCase(), name = get(r, 'name'), email = get(r, 'email').toLowerCase(), dept = get(r, 'department');
    const role = ROLES.find(x => x.toLowerCase() === get(r, 'role').toLowerCase()) || 'Employee';
    const problem = !ID_RE.test(id) ? 'invalid id' : !name ? 'missing name' : !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? 'invalid email'
      : !dept ? 'missing department' : db.get('SELECT 1 FROM employees WHERE id=? OR email=?', id, email) ? 'id or email already exists' : null;
    if (problem) { console.log(`  skip line ${line} (${id || '?'}): ${problem}`); skipped++; continue; }
    if (active >= config.maxEmployees) { console.log(`  STOP: seat capacity ${config.maxEmployees} reached at line ${line}.`); break; }
    const pass = fixed || password.generate();
    db.run(`INSERT INTO employees(id,name,email,role,department,pwh,tracking_number,avatar_initials,job_title,phone,birthday,hire_date,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      id, name, email, role, dept, await password.hash(pass), tracking(dept, id), initials(name),
      get(r, 'job_title'), get(r, 'phone'), get(r, 'birthday'), get(r, 'hire_date'), now());
    db.run("INSERT INTO audit_log(actor_id,action,details,ip_address,created_at) VALUES('CLI','USER_IMPORTED',?, 'local', ?)", `${id} — ${name} (${role})`, now());
    if (!fixed) creds.push([id, name, pass]);
    added++; active++;
  }
  console.log(`\n  Imported ${added}, skipped ${skipped}. Active seats: ${active}/${config.maxEmployees}`);
  if (creds.length > 1) {
    const out = path.join(path.dirname(path.resolve(file)), path.basename(file, path.extname(file)) + '_credentials.csv');
    fs.writeFileSync(out, creds.map(r => r.join(',')).join('\n') + '\n');
    console.log(`  Initial passwords: ${out}\n  Distribute them securely, then DELETE that file. Employees can change passwords in Settings.`);
  }
  db.close();
})().catch(e => { console.error(e); process.exit(1); });
