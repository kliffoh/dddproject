'use strict';
/**
 * Live presence registry.
 *
 * v5 stored one socket per employee, so closing a second browser tab marked a
 * still-working employee as OFFLINE. Here each employee owns a SET of sockets
 * and is offline only when the last one closes.
 *
 * Supervisor sockets are indexed separately, so a broadcast costs
 * O(#supervisors) instead of O(#everyone online) — with 550 users that is the
 * difference between ~20 and ~550 iterations per status change.
 */
const { isSupervisor } = require('../core/roles');

const online = new Map();          // empId -> { sockets:Set, name, role, dept, status, lastActivity, lastAlertAt, since }
const supervisorIds = new Set();

function add(emp, ws) {
  let u = online.get(emp.id);
  const first = !u;
  if (!u) {
    u = { sockets: new Set(), name: emp.name, role: emp.role, dept: emp.department,
          status: 'ONLINE', lastActivity: Date.now(), lastAlertAt: 0, since: Date.now() };
    online.set(emp.id, u);
  }
  u.sockets.add(ws);
  if (isSupervisor(emp.role)) supervisorIds.add(emp.id);
  return first;
}

/** @returns {boolean} true when the employee went fully offline */
function remove(empId, ws) {
  const u = online.get(empId);
  if (!u) return false;
  u.sockets.delete(ws);
  if (u.sockets.size) return false;
  online.delete(empId);
  supervisorIds.delete(empId);
  return true;
}

function kick(empId, reason = 'Session ended') {
  const u = online.get(empId);
  if (!u) return;
  for (const ws of u.sockets) { try { ws.close(4001, reason); } catch (_) {} }
  online.delete(empId);
  supervisorIds.delete(empId);
}

function touch(empId, status, activityTs = Date.now()) {
  const u = online.get(empId);
  if (!u) return null;
  u.lastActivity = activityTs;
  if (status && status !== u.status) { u.status = status; return u; }
  return null;
}

function setStatus(empId, status) { const u = online.get(empId); if (u) { u.status = status; u.lastActivity = Date.now(); } }

function send(ws, msg) { if (ws.readyState === 1) ws.send(typeof msg === 'string' ? msg : JSON.stringify(msg)); }

function toSupervisors(msg) {
  const payload = JSON.stringify(msg);
  for (const id of supervisorIds) {
    const u = online.get(id);
    if (u) for (const ws of u.sockets) send(ws, payload);
  }
}

function toEmployee(empId, msg) {
  const u = online.get(empId);
  if (u) { const p = JSON.stringify(msg); for (const ws of u.sockets) send(ws, p); }
}

function list() {
  const t = Date.now();
  return [...online.entries()].map(([id, u]) => ({
    id, name: u.name, role: u.role, department: u.dept, status: u.status,
    inactiveMin: Math.floor((t - u.lastActivity) / 60000), tabs: u.sockets.size
  })).sort((a, b) => a.name.localeCompare(b.name));
}

module.exports = { online, add, remove, kick, touch, setStatus, toSupervisors, toEmployee, list,
  get size() { return online.size; } };
