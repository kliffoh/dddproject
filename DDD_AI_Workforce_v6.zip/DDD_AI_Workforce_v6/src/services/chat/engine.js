'use strict';
/**
 * Mr. Uber • 8u113t — retrieval-augmented assistant.
 *
 *  ┌──────────┐  ┌──────────┐  ┌────────────┐  ┌────────────┐  ┌───────────┐  ┌──────────┐
 *  │ language │→ │  intent  │→ │  context   │→ │ BM25F +    │→ │ calibrated│→ │ compose  │
 *  │   ID     │  │ (NB, on- │  │ rewriting  │  │ expansion +│  │ confidence│  │ extract- │
 *  │ (EN/SW)  │  │  line)   │  │ (memory)   │  │ typo fix + │  │           │  │ ive / LLM│
 *  └──────────┘  └──────────┘  └────────────┘  │ feedback   │  └───────────┘  └──────────┘
 *                                              │ prior      │        │
 *                                              └────────────┘        ▼
 *                         employee 👍/👎  ──►  note priors + NB training  (learning loop)
 *                         supervisor "teach" ─► new note + NB example     (knowledge-gap loop)
 *
 * Principles
 *  1. Answer the QUESTION, not the document: extract the most relevant
 *     sentences instead of dumping whole notes.
 *  2. Know what you don't know: confidence is calibrated from query coverage,
 *     term match ratio and the top-1/top-2 margin; low confidence is routed to
 *     humans and logged as a knowledge gap rather than hallucinated.
 *  3. Learn from use: helpfulness feedback is a Beta-Bernoulli prior on each
 *     note, and confirmed queries become new training examples.
 */
const db = require('../../db/database');
const log = require('../../core/logger');
const { now, eat, isoAgo } = require('../../core/time');
const text = require('./text');
const lexicon = require('./lexicon');
const intents = require('./intent');
const llm = require('./llm');
const { BM25Index } = require('./bm25');

// ─── Index + priors cache ───────────────────────────────────────────────────
let index = null;
const priors = new Map();          // noteId -> { helpful, unhelpful }

function buildIndex() {
  const notes = db.all('SELECT id, title, content, category, language FROM chatbot_notes ORDER BY id');
  index = new BM25Index(notes);
  priors.clear();
  for (const r of db.all('SELECT note_id, helpful, unhelpful FROM note_stats')) priors.set(r.note_id, { helpful: r.helpful, unhelpful: r.unhelpful });
  return index;
}
const getIndex = () => index || buildIndex();
function invalidate() { index = null; }

function init() {
  const extra = db.all('SELECT text, intent FROM intent_training ORDER BY id DESC LIMIT 5000');
  intents.train(extra);
  buildIndex();
  log.info(`Chat engine ready — ${index.N} notes indexed, ${extra.length} learned intent examples, LLM: ${llm.enabled() ? 'on' : 'off'}`);
}

/** Beta(1+h, 1+u) posterior mean → multiplicative rerank factor in [0.85, 1.15]. */
function priorFactor(noteId) {
  const p = priors.get(noteId);
  if (!p) return 1;
  const mean = (1 + p.helpful) / (2 + p.helpful + p.unhelpful);
  return 0.85 + 0.3 * mean;
}

// ─── Short-term conversational memory ───────────────────────────────────────
const lastTurn = new Map();        // empId -> { terms, sourceIds, at }
const MEMORY_MS = 30 * 60 * 1000;

function recentHistory(empId, n = 6) {
  return db.all('SELECT role, content FROM chat_history WHERE employee_id=? ORDER BY id DESC LIMIT ?', empId, n).reverse();
}

// ─── Canned, bilingual copy ─────────────────────────────────────────────────
const COPY = {
  en: {
    greeting: "Habari! I'm **Mr. Uber • 8u113t**, your DDD assistant. Ask me about leave, shifts, breaks, pay, benefits or company policy.",
    thanks: "Karibu! Glad that helped. Anything else I can look up for you?",
    footerKB: '_Source: DDD knowledge base_',
    gap: "I've logged this question so a supervisor can add the answer to my knowledge base.",
    tellMe: (t) => `Tell me about ${t}`,
    fallback: {
      leave: "For leave requests, open **Leave & Absence** on your dashboard. Your supervisor reviews requests promptly.",
      payroll: "For salary and payslip questions, please visit the HR desk at reception — they can see your payroll record.",
      technical: "For account or system problems, contact your IT administrator or the reception desk. You can change your own password under **Settings**.",
      welfare: "For benefits and welfare details, the HR desk at reception has the current information.",
      attendance: "You can manage work and breaks from **My Time Clock**; your 8-hour target is tracked automatically.",
      hr_policy: "For policy questions, please check the employee handbook or speak to HR at reception.",
      general: "I couldn't find a confident answer to that in our knowledge base. Try rephrasing, or the team at reception will gladly help."
    },
    starters: ['How many leave days do I get?', 'What are the shift hours?', 'How does overtime work?']
  },
  sw: {
    greeting: "Habari! Mimi ni **Mr. Uber • 8u113t**, msaidizi wako wa DDD. Niulize kuhusu likizo, zamu, mapumziko, mshahara, marupurupu au sera za kampuni.",
    thanks: "Karibu sana! Kuna kitu kingine naweza kukusaidia?",
    footerKB: '_Chanzo: hifadhi ya maarifa ya DDD_',
    gap: 'Nimehifadhi swali hili ili msimamizi aongeze jibu kwenye hifadhi yangu ya maarifa.',
    tellMe: (t) => `Niambie kuhusu ${t}`,
    fallback: {
      leave: "Kwa maombi ya likizo, fungua **Leave & Absence** kwenye dashibodi yako. Msimamizi wako atapitia ombi lako haraka.",
      payroll: "Kwa maswali ya mshahara na payslip, tafadhali tembelea dawati la HR kwenye mapokezi.",
      technical: "Kwa matatizo ya akaunti au mfumo, wasiliana na msimamizi wa IT au mapokezi. Unaweza kubadilisha nywila yako kwenye **Settings**.",
      welfare: "Kwa maelezo ya marupurupu na ustawi, dawati la HR kwenye mapokezi lina taarifa za sasa.",
      attendance: "Simamia kazi na mapumziko yako kutoka **My Time Clock**; lengo lako la saa 8 linafuatiliwa kiotomatiki.",
      hr_policy: "Kwa maswali ya sera, angalia kitabu cha mwongozo wa mfanyakazi au ongea na HR kwenye mapokezi.",
      general: "Sikupata jibu la uhakika kwenye hifadhi yetu ya maarifa. Jaribu kuuliza kwa njia nyingine, au timu ya mapokezi itakusaidia."
    },
    starters: ['Nina siku ngapi za likizo?', 'Saa za kazi ni zipi?', 'Mapumziko ni muda gani?']
  }
};

// ─── Developer easter egg (preserved from v5) ───────────────────────────────
const DEV_RE = [
  /who\s+(is|made|created|built|wrote|developed|owns|runs|controls)\s+(you|this|mr\.?\s*uber|ddd|the\s+(bot|system|app))/i,
  /who\s+is\s+(your\s+)?(developer|creator|maker|author|owner)/i,
  /(your|the)\s+(developer|creator|maker|author)\b/i,
  /who\s+is\s+behind\s+(you|this|mr\.?\s*uber|ddd)/i,
  /nani\s+(ndiye\s+)?(aliyekutengeneza|aliyekuunda|mmiliki)/i, /aliyekutengeneza|aliyekuunda/i
];
const MASK = '   ___     ___\n  /   \\   /   \\\n | o o | | o o |\n |  U  | |  n  |\n  \\___/   \\___/';
function developerAnswer(lang) {
  const body = lang === 'sw'
    ? 'Mtengenezaji wangu ni **Clive Otieno** — *The Anonymous Developer* wa DDD. Hana namba ya ufuatiliaji. Ni msimbo, ukimya, na matokeo tu.'
    : 'My developer is **Clive Otieno** — *The Anonymous Developer* of DDD. No tracking number. No paper trail. Just code, silence, and results.';
  return `[[ANON]]\n${MASK}\n[[/ANON]]\n**ANONYMOUS**\n\n${body}`;
}

// ─── Answer composition ─────────────────────────────────────────────────────
/** Pick the sentences of a note that best answer the query (extractive QA). */
function extract(note, weights, maxSentences = 2) {
  const sents = text.sentences(note.content);
  if (sents.length <= maxSentences + 1) return note.content;
  const scored = sents.map((s, i) => {
    const ts = new Set(text.terms(s));
    let sc = 0;
    for (const [t, w] of weights) if (ts.has(t)) sc += w;
    return { s, i, sc: sc + (i === 0 ? 0.15 : 0) };          // slight lead bias
  });
  const top = [...scored].sort((a, b) => b.sc - a.sc).slice(0, maxSentences).sort((a, b) => a.i - b.i);
  return top.map(x => x.s).join(' ');
}

function calibrate(results, weights, qTerms) {
  if (!results.length) return { score: 0, label: 'low' };
  const top = results[0];
  const coverage = Math.min(1, top.score / getIndex().selfScore(weights));
  const uniqueQ = [...new Set(qTerms)];
  const matchedFrac = uniqueQ.length ? Math.min(1, new Set(top.matched).size / uniqueQ.length) : 0;
  const margin = results[1] ? (top.score - results[1].score) / top.score : 1;
  const score = +(0.5 * coverage + 0.3 * matchedFrac + 0.2 * margin).toFixed(3);
  return { score, label: score >= 0.55 ? 'high' : score >= 0.32 ? 'medium' : 'low' };
}

function suggestionsFrom(results, usedIds, lang) {
  const c = COPY[lang];
  const floor = (results[0] ? results[0].score : 0) * 0.3;
  const s = results.filter(r => !usedIds.includes(r.note.id) && r.score >= floor).slice(0, 3).map(r => c.tellMe(r.note.title));
  return s.length ? s : c.starters;
}

function buildSystemPrompt(lang, context) {
  return `You are Mr. Uber • 8u113t, the warm, precise workplace assistant for DDD (Digital Divide Data) employees in Kenya.

LANGUAGE: ${lang === 'sw' ? 'The employee wrote in Kiswahili — reply ONLY in Kiswahili.' : 'Reply in clear, friendly English.'}

KNOWLEDGE BASE EXCERPTS (the ONLY source of company facts):
${context || '(no relevant notes found)'}

RULES
- Use only facts from the excerpts. Never invent numbers, dates, names or policies.
- If the excerpts do not answer the question, say so briefly and suggest the HR desk at reception.
- 2–4 sentences. Lead with the direct answer. Use **bold** for key numbers.
- Use the conversation history to resolve follow-ups like "how many days is it?".
- Current time: ${eat()} (EAT).`;
}

// ─── Main entry point ───────────────────────────────────────────────────────
/**
 * @param {object} emp       authenticated employee row
 * @param {string} message
 * @param {{onMeta?:Function, onDelta?:Function}} hooks  streaming callbacks
 */
async function answer(emp, message, hooks = {}) {
  const started = Date.now();
  const language = text.detectLanguage(message);
  const copy = COPY[language];
  const qTerms = text.terms(message);
  let { intent } = intents.classify(message);

  let response = '', confidence = 'low', score = 0, sources = [], suggestions = [], mode = 'kb';

  const emitMeta = () => hooks.onMeta && hooks.onMeta({ intent, language, keywords: qTerms });

  if (DEV_RE.some(r => r.test(message))) {
    intent = 'developer'; emitMeta();
    response = developerAnswer(language); confidence = 'high'; score = 1; mode = 'canned';
  } else if (intent === 'greeting' || intent === 'thanks') {
    emitMeta();
    response = copy[intent]; confidence = 'high'; score = 1; mode = 'canned';
    suggestions = copy.starters;
  } else {
    // 1. Contextual query rewriting from short-term memory
    const mem = lastTurn.get(emp.id);
    const fresh = mem && Date.now() - mem.at < MEMORY_MS;
    const tokens = text.tokenize(message);
    const topicTerms = qTerms.filter(t => !text.MORE_WORDS.has(t));
    // "tell me more" / "explain" with no new topic of its own
    const wantsMore = fresh && tokens.some(t => text.MORE_WORDS.has(t)) && topicTerms.length === 0;
    // A follow-up must signal it: an anaphor ("is it paid?") or an empty topic.
    const followUp = fresh && !wantsMore && (tokens.some(t => text.ANAPHORA.has(t)) || topicTerms.length === 0);

    const weights = lexicon.expand(qTerms);
    if (followUp && mem) for (const t of mem.terms) lexicon.addTerm(weights, t, 0.6);

    // 2. Retrieve + rerank with learned priors and language preference
    let results = getIndex().search(weights, 6).map(r => {
      let f = priorFactor(r.note.id);
      if (r.note.language === 'sw') f *= language === 'sw' ? 1.15 : 0.8;
      return { ...r, score: r.score * f };
    }).sort((a, b) => b.score - a.score);

    if (wantsMore && mem.sourceIds.length) {
      const prev = db.get('SELECT id,title,content,category,language FROM chatbot_notes WHERE id=?', mem.sourceIds[0]);
      if (prev) results = [{ note: prev, score: 99, matched: qTerms }, ...results.filter(r => r.note.id !== prev.id)];
    }

    const cal = wantsMore ? { score: 0.9, label: 'high' } : calibrate(results, weights, followUp ? [...qTerms, ...mem.terms] : qTerms);
    confidence = cal.label; score = cal.score;
    if (intent === 'general' && results.length && confidence !== 'low') {
      intent = intents.classify(`${message} ${results[0].note.title}`).intent;   // let the KB disambiguate intent
    }
    emitMeta();

    const relevant = results.filter(r => r.score >= results[0]?.score * 0.6).slice(0, 3);

    // High-confidence direct hits are answered extractively (instant, exact, free);
    // everything else that has *some* grounding goes to the LLM when configured.
    const useLLM = llm.enabled() && results.length > 0 && (confidence !== 'high' || followUp);
    if (useLLM) {
      // 3a. Grounded generation, streamed token-by-token
      mode = 'llm';
      const context = relevant.map(r => `[${r.note.category}] ${r.note.title}: ${r.note.content}`).join('\n\n');
      const history = recentHistory(emp.id, 6).map(h => ({ role: h.role === 'assistant' ? 'assistant' : 'user', content: h.content.slice(0, 1500) }));
      while (history.length && history[0].role !== 'user') history.shift();
      try {
        response = await llm.stream({ system: buildSystemPrompt(language, context), messages: [...history, { role: 'user', content: message }], onDelta: hooks.onDelta });
        sources = relevant.map(r => r.note);
        if (confidence === 'low') confidence = 'medium';
      } catch (e) {
        log.error('llm', e);
        mode = 'kb'; response = '';
      }
    }

    if (!response) {
      if (confidence !== 'low' && results.length) {
        // 3b. Extractive answer from the best note (+ a close runner-up)
        const best = results[0];
        const parts = [`**${best.note.title}**\n${wantsMore ? best.note.content : extract(best.note, weights)}`];
        sources = [best.note];
        const second = results[1];
        if (!wantsMore && second && second.score >= best.score * 0.8 && confidence !== 'high') {
          parts.push(`**${second.note.title}**\n${extract(second.note, weights, 1)}`);
          sources.push(second.note);
        }
        response = `${parts.join('\n\n')}\n\n${copy.footerKB}`;
      } else {
        // 3c. Honest fallback + knowledge-gap logging
        response = `${copy.fallback[intent] || copy.fallback.general}\n\n${copy.gap}`;
        confidence = 'low';
      }
    }

    suggestions = suggestionsFrom(results, sources.map(s => s.id), language);
    lastTurn.set(emp.id, { terms: qTerms.length ? qTerms : (mem ? mem.terms : []), sourceIds: sources.map(s => s.id), at: Date.now() });
  }

  // 4. Persist (single transaction)
  let queryId = 0;
  db.tx(() => {
    db.run('INSERT INTO chat_history(employee_id,role,content,created_at) VALUES(?,?,?,?)', emp.id, 'user', message, now());
    db.run('INSERT INTO chat_history(employee_id,role,content,created_at) VALUES(?,?,?,?)', emp.id, 'assistant', response, now());
    queryId = db.run(`INSERT INTO chat_queries(employee_id,query,response,intent,confidence,language,keywords,sources,score,created_at)
                      VALUES(?,?,?,?,?,?,?,?,?,?)`,
      emp.id, message, response, intent, confidence, language, qTerms.join(','), sources.map(s => s.id).join(','), score, now()).lastInsertRowid;
    for (const s of sources) {
      db.run('INSERT INTO note_stats(note_id,served) VALUES(?,1) ON CONFLICT(note_id) DO UPDATE SET served=served+1', s.id);
    }
  });

  const result = {
    id: queryId, response, intent, confidence, confidenceScore: score, language, keywords: qTerms,
    sources: sources.map(s => s.title), suggestions, mode, latencyMs: Date.now() - started
  };
  log.chat(emp.id, message, result);
  return result;
}

// ─── Learning loop ──────────────────────────────────────────────────────────
function feedback(emp, queryId, helpful) {
  const q = db.get('SELECT * FROM chat_queries WHERE id=? AND employee_id=?', queryId, emp.id);
  if (!q) return false;
  if (q.feedback !== null && q.feedback !== undefined) return true;          // idempotent
  const v = helpful ? 1 : -1;
  db.tx(() => {
    db.run('UPDATE chat_queries SET feedback=? WHERE id=?', v, queryId);
    for (const id of String(q.sources || '').split(',').filter(Boolean).map(Number)) {
      db.run(`INSERT INTO note_stats(note_id,helpful,unhelpful) VALUES(?,?,?)
              ON CONFLICT(note_id) DO UPDATE SET helpful=helpful+excluded.helpful, unhelpful=unhelpful+excluded.unhelpful`,
        id, helpful ? 1 : 0, helpful ? 0 : 1);
      const p = priors.get(id) || { helpful: 0, unhelpful: 0 };
      if (helpful) p.helpful++; else p.unhelpful++;
      priors.set(id, p);
    }
    if (helpful && !['general', 'developer', 'greeting', 'thanks'].includes(q.intent)) {
      db.run('INSERT INTO intent_training(text,intent,source,created_at) VALUES(?,?,?,?)', q.query, q.intent, 'feedback', now());
      intents.learn(q.query, q.intent);
    }
    if (!helpful) db.run('UPDATE chat_queries SET resolved=0 WHERE id=?', queryId);
  });
  return true;
}

function teach(actorId, queryId, { title, content, category, intent }) {
  const q = db.get('SELECT * FROM chat_queries WHERE id=?', queryId);
  const noteId = db.tx(() => {
    const id = db.run('INSERT INTO chatbot_notes(title,content,category,language,created_by,created_at) VALUES(?,?,?,?,?,?)',
      title, content, category || 'General', q ? q.language : 'multi', actorId, now()).lastInsertRowid;
    if (q) {
      db.run('UPDATE chat_queries SET resolved=1 WHERE id=?', queryId);
      const label = intent || (q.intent !== 'general' ? q.intent : null);
      if (label) { db.run('INSERT INTO intent_training(text,intent,source,created_at) VALUES(?,?,?,?)', q.query, label, 'teach', now()); intents.learn(q.query, label); }
    }
    return id;
  });
  invalidate();
  return noteId;
}

/** Knowledge-gap analytics: what are people asking that the KB cannot answer? */
function gaps(days = 30) {
  const rows = db.all(`SELECT cq.id, cq.query, cq.keywords, cq.intent, cq.created_at, cq.feedback, e.name
                       FROM chat_queries cq JOIN employees e ON e.id=cq.employee_id
                       WHERE (cq.confidence='low' OR cq.feedback=-1) AND cq.resolved=0 AND cq.created_at >= ?
                       ORDER BY cq.id DESC LIMIT 300`, isoAgo(days * 86400000));
  const freq = new Map();
  for (const r of rows) for (const k of String(r.keywords || '').split(',').filter(Boolean)) freq.set(k, (freq.get(k) || 0) + 1);
  const topTerms = [...freq.entries()].sort((a, b) => b[1] - a[1]).slice(0, 15).map(([term, count]) => ({ term, count }));
  const totals = db.get(`SELECT COUNT(*) AS total,
                           SUM(CASE WHEN confidence='high' THEN 1 ELSE 0 END) AS high,
                           SUM(CASE WHEN confidence='low' THEN 1 ELSE 0 END) AS low,
                           SUM(CASE WHEN feedback=1 THEN 1 ELSE 0 END) AS helpful,
                           SUM(CASE WHEN feedback=-1 THEN 1 ELSE 0 END) AS unhelpful
                         FROM chat_queries WHERE created_at >= ?`, isoAgo(days * 86400000));
  return { totals, topTerms, queries: rows.slice(0, 100) };
}

module.exports = { init, answer, feedback, teach, gaps, invalidate };
