'use strict';
/**
 * BM25F retrieval index (Robertson & Zaragoza, 2009) over the knowledge base.
 *
 * Why BM25 over the v5 ad-hoc TF-IDF:
 *   • Term-frequency SATURATION (k1): a note that repeats "leave" ten times is
 *     not ten times more relevant.
 *   • Proper LENGTH NORMALISATION (b): long policies are not unfairly favoured
 *     or punished.
 *   • FIELD WEIGHTING (the "F"): a match in the title is stronger evidence than
 *     a match in the body.
 *
 * The index is built once and cached; it is rebuilt only when the knowledge
 * base changes (v5 rebuilt the corpus on every single chat message).
 *
 * Out-of-vocabulary query terms are corrected against the index vocabulary with
 * Damerau-Levenshtein distance, so "levae", "salry" and "overtme" still match.
 */
const { terms, editDistance } = require('./text');

const K1 = 1.2, B = 0.75;
const FIELD_WEIGHT = { title: 2.5, category: 1.2, content: 1.0 };

class BM25Index {
  constructor(notes) {
    this.docs = notes.map(n => {
      const fields = { title: terms(n.title), category: terms(n.category || ''), content: terms(n.content) };
      const tf = new Map();
      let len = 0;
      for (const [f, toks] of Object.entries(fields)) {
        for (const t of toks) { tf.set(t, (tf.get(t) || 0) + FIELD_WEIGHT[f]); len += FIELD_WEIGHT[f]; }
      }
      return { note: n, tf, len };
    });
    this.N = this.docs.length;
    this.avgLen = this.docs.reduce((s, d) => s + d.len, 0) / (this.N || 1);
    this.df = new Map();
    for (const d of this.docs) for (const t of d.tf.keys()) this.df.set(t, (this.df.get(t) || 0) + 1);
    this.vocab = [...this.df.keys()];
  }

  idf(t) {
    const n = this.df.get(t) || 0;
    return Math.log(1 + (this.N - n + 0.5) / (n + 0.5));     // BM25+ style, always positive
  }

  /** Map unknown query terms to their closest vocabulary term (typo tolerance). */
  correct(weights) {
    const out = new Map(weights);
    out.group = new Map(weights.group || []);
    const put = (term, w, from) => { if (!out.has(term)) { out.set(term, w); out.group.set(term, out.group.get(from) || from); } };
    for (const [t, w] of weights) {
      if (this.df.has(t) || t.length < 4) continue;
      // Morphological variant: "harass" → "harassment", "approv" → "approval"
      if (t.length >= 5) {
        const pref = this.vocab.find(v => v.startsWith(t) || (v.length >= 5 && t.startsWith(v)));
        if (pref) { put(pref, w * 0.85, t); continue; }
      }
      const maxD = t.length >= 7 ? 2 : 1;
      let best = null, bestD = maxD + 1;
      for (const v of this.vocab) {
        if (Math.abs(v.length - t.length) > maxD) continue;
        const dist = editDistance(t, v, maxD);
        if (dist < bestD) { bestD = dist; best = v; }
      }
      if (best) put(best, w * (bestD === 1 ? 0.8 : 0.6), t);
    }
    return out;
  }

  /**
   * @param {Map<string,number>} weightedTerms
   * @returns {{note:object, score:number, matched:string[]}[]} sorted desc
   */
  search(weightedTerms, topK = 5) {
    if (!this.N) return [];
    const q = this.correct(weightedTerms);
    const results = [];
    for (const d of this.docs) {
      const pooled = new Map();                 // group -> best contribution
      const matched = [];
      for (const [t, w] of q) {
        const f = d.tf.get(t);
        if (!f) continue;
        const norm = f * (K1 + 1) / (f + K1 * (1 - B + B * d.len / this.avgLen));
        const contrib = w * this.idf(t) * norm;
        const g = q.group.get(t) || t;
        if (contrib > (pooled.get(g) || 0)) pooled.set(g, contrib);
        if (w >= 0.6) matched.push(t);
      }
      let score = 0;
      for (const v of pooled.values()) score += v;
      if (score > 0) results.push({ note: d.note, score, matched });
    }
    results.sort((a, b) => b.score - a.score);
    return results.slice(0, topK);
  }

  /** Upper bound used for score calibration: the query scored against itself. */
  selfScore(weightedTerms) {
    let s = 0;
    for (const [t, w] of weightedTerms) if (w >= 1) s += w * this.idf(t) * (K1 + 1) / (1 + K1);
    return s || 1;
  }
}

module.exports = { BM25Index };
