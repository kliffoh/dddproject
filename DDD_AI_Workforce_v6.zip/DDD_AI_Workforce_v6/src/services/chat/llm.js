'use strict';
/**
 * Minimal streaming client for the Anthropic Messages API (no SDK dependency).
 * Tokens are forwarded to the browser as they arrive, so the first words of a
 * generative answer appear in well under a second instead of after the whole
 * completion — the single biggest factor in how "responsive" a chatbot feels.
 */
const config = require('../../config');

const enabled = () => Boolean(config.anthropicKey);

async function stream({ system, messages, onDelta, timeoutMs = 25000, maxTokens = 600 }) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      signal: ctrl.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': config.anthropicKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: config.anthropicModel, max_tokens: maxTokens, system, messages, stream: true })
    });
    if (!res.ok || !res.body) throw new Error(`Anthropic API ${res.status}: ${(await res.text()).slice(0, 200)}`);

    const decoder = new TextDecoder();
    let buf = '', full = '';
    for await (const chunk of res.body) {
      buf += decoder.decode(chunk, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const event = buf.slice(0, idx); buf = buf.slice(idx + 2);
        const dataLine = event.split('\n').find(l => l.startsWith('data:'));
        if (!dataLine) continue;
        let data; try { data = JSON.parse(dataLine.slice(5).trim()); } catch (_) { continue; }
        if (data.type === 'content_block_delta' && data.delta && data.delta.type === 'text_delta') {
          full += data.delta.text;
          if (onDelta) onDelta(data.delta.text);
        } else if (data.type === 'error') {
          throw new Error(data.error && data.error.message || 'stream error');
        }
      }
    }
    return full.trim();
  } finally { clearTimeout(timer); }
}

module.exports = { enabled, stream };
