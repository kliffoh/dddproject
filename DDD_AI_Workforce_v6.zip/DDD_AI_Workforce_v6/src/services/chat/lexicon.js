'use strict';
/**
 * Bilingual concept lexicon used for QUERY EXPANSION.
 *
 * Classic IR problem: the vocabulary mismatch between how employees ask
 * ("can I get time off?", "nataka likizo") and how policies are written
 * ("Annual Leave Policy"). Each concept groups English and Kiswahili surface
 * forms; a query term pulls in its siblings at a reduced weight, so exact
 * matches still dominate the ranking.
 */
const { stem } = require('./text');

const CONCEPTS = {
  leave:      ['leave', 'vacation', 'holiday', 'timeoff', 'off', 'annual', 'likizo', 'absence', 'absent', 'days'],
  sick:       ['sick', 'ill', 'illness', 'medical', 'doctor', 'hospital', 'ugonjwa', 'mgonjwa', 'hospitali', 'daktari'],
  parental:   ['maternity', 'paternity', 'pregnant', 'baby', 'birth', 'uzazi', 'mjamzito', 'mtoto'],
  pay:        ['salary', 'pay', 'paid', 'payslip', 'wage', 'wages', 'payroll', 'mshahara', 'malipo', 'pesa', 'money'],
  deductions: ['nhif', 'sha', 'shif', 'nssf', 'housing', 'levy', 'deduction', 'deductions', 'tax', 'paye', 'kra', 'makato', 'kodi'],
  health:     ['health', 'insurance', 'medical', 'cover', 'wellness', 'afya', 'bima', 'ustawi'],
  hours:      ['hours', 'shift', 'schedule', 'time', 'start', 'finish', 'saa', 'zamu', 'ratiba', 'muda'],
  break:      ['break', 'lunch', 'tea', 'rest', 'pause', 'mapumziko', 'chai', 'chakula'],
  overtime:   ['overtime', 'extra', 'ot', 'ziada'],
  weekend:    ['weekend', 'weekends', 'saturday', 'sunday', 'holiday', 'holidays', 'jumamosi', 'jumapili', 'sikukuu'],
  account:    ['password', 'login', 'signin', 'account', 'locked', 'reset', 'nywila', 'akaunti', 'kuingia', 'neno'],
  grievance:  ['grievance', 'complaint', 'harassment', 'report', 'abuse', 'malalamiko', 'unyanyasaji', 'lalamiko'],
  policy:     ['policy', 'rule', 'rules', 'regulation', 'handbook', 'sera', 'kanuni', 'sheria']
};

const termToConcepts = new Map();
for (const [concept, words] of Object.entries(CONCEPTS)) {
  for (const w of words) {
    const s = stem(w);
    if (!termToConcepts.has(s)) termToConcepts.set(s, new Set());
    termToConcepts.get(s).add(concept);
  }
}
const conceptTerms = Object.fromEntries(Object.entries(CONCEPTS).map(([c, ws]) => [c, [...new Set(ws.map(stem))]]));

/**
 * Weighted query vector with CONCEPT POOLING.
 * `weights` maps term -> weight; `weights.group` maps term -> pooling group.
 * Synonyms pulled in from one concept share a group, and BM25 takes the MAX
 * within a group instead of the sum — otherwise one query word ("paid") that
 * expands into eleven pay-related synonyms would be counted eleven times.
 *
 * @param {string[]} qTerms stemmed query terms
 * @returns {Map<string, number> & {group: Map<string,string>}}
 */
function expand(qTerms, expansionWeight = 0.25) {
  const weights = new Map();
  weights.group = new Map();
  for (const t of qTerms) { weights.set(t, 1); weights.group.set(t, t); }
  for (const t of qTerms) {
    for (const c of termToConcepts.get(t) || []) {
      for (const sib of conceptTerms[c]) {
        if (!weights.has(sib)) { weights.set(sib, expansionWeight); weights.group.set(sib, `§${c}`); }
      }
    }
  }
  return weights;
}

/** Add a term with its own group (used by memory / typo correction). */
function addTerm(weights, term, w, group = term) {
  if (weights.has(term)) return;
  weights.set(term, w);
  if (!weights.group) weights.group = new Map();
  weights.group.set(term, group);
}

const conceptsOf = (qTerms) => {
  const out = new Set();
  for (const t of qTerms) for (const c of termToConcepts.get(t) || []) out.add(c);
  return [...out];
};

module.exports = { expand, addTerm, conceptsOf, CONCEPTS };
