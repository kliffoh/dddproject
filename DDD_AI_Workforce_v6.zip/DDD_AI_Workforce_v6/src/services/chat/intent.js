'use strict';
/**
 * Multinomial Naive Bayes intent classifier with ONLINE LEARNING.
 *
 * v5 used "first keyword list that matches wins", so "my salary for sick days"
 * was classified by whichever list happened to be checked first. NB instead
 * combines ALL evidence probabilistically:
 *
 *     P(intent | words) ∝ P(intent) · Π P(word | intent)      (Laplace-smoothed)
 *
 * Features = stemmed content terms + lexicon concepts (bilingual bridge).
 *
 * Learning loop: when an employee marks an answer helpful, or a supervisor
 * teaches the bot, the (text, intent) pair is persisted to `intent_training`
 * and folded into the model immediately — the classifier improves with use,
 * with no retraining job and no restart.
 */
const { terms } = require('./text');
const { conceptsOf } = require('./lexicon');

const SEED = {
  leave: ['how many leave days do i have', 'i want to apply for annual leave', 'can i take a day off tomorrow',
    'vacation request', 'maternity leave duration', 'paternity leave days', 'sick leave rules', 'compassionate leave',
    'nataka kuomba likizo', 'siku ngapi za likizo', 'likizo ya uzazi', 'naomba likizo kesho', 'likizo ya ugonjwa'],
  payroll: ['when is salary paid', 'i did not receive my payslip', 'how is overtime paid', 'deductions on my pay',
    'nssf and sha contributions', 'tax deduction question', 'allowance and bonus',
    'mshahara unalipwa lini', 'sijapata payslip', 'makato ya mshahara', 'malipo ya ziada'],
  technical: ['i forgot my password', 'cannot log in to the system', 'my account is locked', 'reset my password',
    'the system shows an error', 'computer not working',
    'nimesahau nywila', 'siwezi kuingia kwenye mfumo', 'akaunti yangu imefungwa'],
  welfare: ['health insurance cover', 'medical benefits', 'wellness programme', 'counselling support', 'staff welfare',
    'bima ya afya', 'huduma za afya', 'ustawi wa wafanyakazi'],
  attendance: ['what time does my shift start', 'how long is lunch break', 'how do breaks work', 'clock in and clock out',
    'working hours per day', 'overtime starts when', 'i was late today',
    'saa za kazi ni ngapi', 'mapumziko ni muda gani', 'zamu inaanza saa ngapi'],
  hr_policy: ['how do i report harassment', 'grievance procedure', 'company policy on discipline', 'contract renewal',
    'promotion and appraisal', 'code of conduct',
    'sera ya kampuni', 'jinsi ya kuripoti malalamiko', 'mkataba wa kazi'],
  greeting: ['hello', 'hi there', 'good morning', 'good afternoon', 'hey', 'habari', 'jambo', 'mambo vipi', 'habari za asubuhi', 'sasa'],
  thanks: ['thank you', 'thanks a lot', 'that helped', 'great thanks', 'asante sana', 'asante', 'shukrani']
};

class NaiveBayes {
  constructor(alpha = 1) { this.alpha = alpha; this.reset(); }

  reset() {
    this.docCount = new Map();      // intent -> #docs
    this.wordCount = new Map();     // intent -> Map(feature -> count)
    this.totalWords = new Map();    // intent -> total feature count
    this.vocab = new Set();
    this.N = 0;
  }

  static features(text) {
    const t = terms(text);
    return [...t, ...conceptsOf(t).map(c => `§${c}`)];
  }

  learn(text, intent) {
    const feats = NaiveBayes.features(text);
    if (!feats.length) return;
    this.N++;
    this.docCount.set(intent, (this.docCount.get(intent) || 0) + 1);
    if (!this.wordCount.has(intent)) this.wordCount.set(intent, new Map());
    const wc = this.wordCount.get(intent);
    for (const f of feats) {
      wc.set(f, (wc.get(f) || 0) + 1);
      this.totalWords.set(intent, (this.totalWords.get(intent) || 0) + 1);
      this.vocab.add(f);
    }
  }

  /** @returns {{intent:string, p:number, known:number}} posterior via log-sum-exp */
  predict(text) {
    const feats = NaiveBayes.features(text);
    const known = feats.filter(f => this.vocab.has(f)).length;
    if (!known) return { intent: 'general', p: 0, known: 0 };
    const V = this.vocab.size;
    const logs = [];
    for (const [intent, dc] of this.docCount) {
      let lp = Math.log(dc / this.N);
      const wc = this.wordCount.get(intent), tw = this.totalWords.get(intent);
      for (const f of feats) {
        if (!this.vocab.has(f)) continue;          // ignore unseen features entirely
        lp += Math.log(((wc.get(f) || 0) + this.alpha) / (tw + this.alpha * V));
      }
      logs.push([intent, lp]);
    }
    const max = Math.max(...logs.map(l => l[1]));
    const z = logs.reduce((s, [, lp]) => s + Math.exp(lp - max), 0);
    logs.sort((a, b) => b[1] - a[1]);
    const [best, lp] = logs[0];
    return { intent: best, p: Math.exp(lp - max) / z, known };
  }
}

const model = new NaiveBayes(1);

function train(extraExamples = []) {
  model.reset();
  for (const [intent, examples] of Object.entries(SEED)) for (const e of examples) model.learn(e, intent);
  for (const { text, intent } of extraExamples) model.learn(text, intent);
}

const GREET_ONLY = /^(hi|hello|hey|habari|jambo|mambo|vipi|sasa|poa|good (morning|afternoon|evening)|habari za (asubuhi|mchana|jioni))[\s!.,]*(there|bot|uber|mr uber)?[\s!.]*$/i;
const THANKS_ONLY = /^(thanks?|thank you|asante( sana)?|shukrani|ok thanks|great|perfect)[\s!.]*$/i;

function classify(text) {
  const t = String(text || '').trim();
  if (GREET_ONLY.test(t)) return { intent: 'greeting', p: 1 };
  if (THANKS_ONLY.test(t)) return { intent: 'thanks', p: 1 };
  const r = model.predict(t);
  // Reject low-evidence predictions instead of guessing.
  if (r.p < 0.35) return { intent: 'general', p: r.p };
  return r;
}

module.exports = { train, classify, learn: (text, intent) => model.learn(text, intent), INTENTS: Object.keys(SEED) };
