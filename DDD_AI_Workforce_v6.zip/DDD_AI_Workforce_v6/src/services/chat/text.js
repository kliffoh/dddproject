'use strict';
/**
 * Text processing primitives for a bilingual (English / Kiswahili) assistant.
 *
 *   normalize → tokenize → stopword filter → light stemming
 *
 * Stemming is deliberately conservative ("light stemming"): in a small,
 * domain-specific corpus, over-stemming merges unrelated words and hurts
 * precision far more than it helps recall.
 */

const EN_STOP = new Set(('the a an is are was were be been being have has had do does did will would shall should may might ' +
  'must can could of to in for on at by with and or but if then than that this these those i you he she it we they my your ' +
  'his her its our their me him us them what which who whom when where why how not no so as from into about over after ' +
  'before between under above please tell want need know get give let there here also just very any some all each every ' +
  'more most less least am im ive id dont does doesnt can cant okay ok thanks thank much many say said like').split(' '));

const SW_STOP = new Set(('na ya wa kwa katika kuhusu ni si je hii hiyo hilo huyu yule wale hawa mimi wewe yeye sisi ninyi ' +
  'wao wangu wako wake wetu wenu hapa pale kule nini wapi lini jinsi kwanini vipi basi tu hata pia au kama ili kwamba ' +
  'kutoka hadi zaidi kidogo sasa bado tena ndiyo hapana sana kabisa labda pengine huenda kweli bila naam halafu la za ' +
  'cha vya za tafadhali naomba asante').split(' '));

const SW_MARKERS = new Set(('habari jambo mambo vipi poa sana nzuri asante karibu tafadhali ndiyo hapana nini wapi lini ' +
  'jinsi kwanini kwa katika kuhusu likizo malipo mshahara saa kazi mfanyakazi meneja msimamizi msaada taarifa siku wiki ' +
  'mwezi mwaka mtu na ya wa ni si je hii hiyo hilo mimi wewe yeye sisi wao wangu wako bado tena pia lakini au kama ili ' +
  'kwamba kwenye kutoka hadi zaidi kidogo sasa leo jana kesho asubuhi mchana jioni usiku dakika sababu napenda ninataka ' +
  'ninahitaji unaweza naweza nifanye kuwa kupata kuuliza naomba samahani hongera pole mapumziko ugonjwa mgonjwa uzazi ' +
  'nywila akaunti mfumo bima afya sera kanuni mkataba nataka nahitaji ngapi gani nani').split(' '));

const ANAPHORA = new Set(['it', 'that', 'this', 'they', 'those', 'these', 'one', 'there', 'hiyo', 'hilo', 'hii', 'hizo', 'huo', 'hayo']);
const MORE_WORDS = new Set(['more', 'elaborate', 'explain', 'details', 'detail', 'expand', 'zaidi', 'eleza', 'fafanua']);

function normalize(text) {
  return String(text || '')
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/['’]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const tokenize = (text) => normalize(text).split(' ').filter(Boolean);

/** Light English stemmer: plural, -ing, -ed, -ly. Swahili tokens pass through. */
const IRREGULAR = { paid: 'pay', took: 'take', taken: 'take', gave: 'give', left: 'leave', children: 'child', women: 'woman', men: 'man' };
function stem(w) {
  if (IRREGULAR[w]) return IRREGULAR[w];
  if (w.length <= 3 || /\d/.test(w)) return w;
  if (w.endsWith('ies') && w.length > 4) return w.slice(0, -3) + 'y';
  if (w.endsWith('sses')) return w.slice(0, -2);
  if (w.endsWith('ing') && w.length > 5) { w = w.slice(0, -3); return dedouble(w); }
  if (w.endsWith('ed') && w.length > 4 && !w.endsWith('eed')) { w = w.slice(0, -2); return dedouble(w); }
  if (w.endsWith('ly') && w.length > 4) return w.slice(0, -2);
  if (w.endsWith('s') && !w.endsWith('ss') && !w.endsWith('us') && !w.endsWith('is') && w.length > 3) return w.slice(0, -1);
  return w;
}
const dedouble = (w) => (/([bdfglmnprt])\1$/.test(w) ? w.slice(0, -1) : w);

/** Content terms: tokenized, stopwords removed, stemmed. */
function terms(text) {
  return tokenize(text).filter(w => w.length > 1 && !EN_STOP.has(w) && !SW_STOP.has(w)).map(stem);
}

/** Lexical language identification with simple Swahili morphology cues. */
function detectLanguage(text) {
  const tokens = tokenize(text);
  if (!tokens.length) return 'en';
  let sw = 0;
  for (const t of tokens) {
    if (SW_MARKERS.has(t)) { sw += 1; continue; }
    if (/^(ni|na|ta|li|ku|wa|ki|vi|m|u)(na|li|ta|me|ka)?[a-z]{3,}a$/.test(t) && t.length > 5) { sw += 0.5; continue; }
    if (/(isha|esha|ika|eka|ana|wa|ni)$/.test(t) && t.length > 6) sw += 0.25;
  }
  return sw / tokens.length >= 0.25 ? 'sw' : 'en';
}

/** Sentence splitter tolerant of abbreviations like "e.g." and times "08:00". */
function sentences(text) {
  return String(text || '')
    .replace(/\b(e\.g|i\.e|etc|approx|no)\./gi, (m) => m.replace('.', '§'))
    .split(/(?<=[.!?])\s+(?=[A-Z0-9])/)
    .map(s => s.replace(/§/g, '.').trim())
    .filter(Boolean);
}

/** Damerau-Levenshtein (optimal string alignment), early exit beyond maxDist. */
function editDistance(a, b, maxDist = 2) {
  if (Math.abs(a.length - b.length) > maxDist) return maxDist + 1;
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    let rowMin = Infinity;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
      if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
      rowMin = Math.min(rowMin, d[i][j]);
    }
    if (rowMin > maxDist) return maxDist + 1;
  }
  return d[a.length][b.length];
}

module.exports = { normalize, tokenize, stem, terms, detectLanguage, sentences, editDistance, ANAPHORA, MORE_WORDS, EN_STOP, SW_STOP };
