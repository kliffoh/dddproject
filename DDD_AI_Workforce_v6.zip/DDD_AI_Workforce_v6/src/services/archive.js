'use strict';
/** Employee removal dossier + offline change log (behaviour preserved from v5, made transactional). */
const fs = require('fs');
const path = require('path');
const db = require('../db/database');
const config = require('../config');
const { now, eat, today, fileStamp } = require('../core/time');
const { LATEST } = require('../db/migrations');

function changeLine(action, target, actor, reason, extra = '') {
  fs.mkdirSync(config.dirs.changes, { recursive: true });
  fs.appendFileSync(path.join(config.dirs.changes, `changes_${today()}.txt`),
    `[${eat()}] ${action} | target=${target.id} | name=${target.name} | role=${target.role} | by=${actor.id} (${actor.name}, ${actor.role})${reason ? ` | reason="${reason}"` : ''}${extra}\n`, 'utf8');
}

function logUserChange(action, target, actor, archiveFile = null, reason = '') {
  db.run('INSERT INTO user_change_log(action,target_id,target_name,actor_id,actor_name,actor_role,archive_file,reason,created_at) VALUES(?,?,?,?,?,?,?,?,?)',
    action, target.id, target.name, actor.id, actor.name, actor.role, archiveFile, reason, now());
  changeLine(action, target, actor, reason, archiveFile ? ` | dossier=${archiveFile}` : '');
}

/** Writes the dossier, then deletes all rows in ONE transaction. */
function archiveAndRemove(emp, actor, reason) {
  const { pwh, ...employee } = emp;
  const filename = `removed_${fileStamp()}_${emp.id}.json`;
  const dossier = {
    _meta: { archived_at: now(), archived_at_eat: eat(), removed_by: { id: actor.id, name: actor.name, role: actor.role },
             reason: reason || '(not specified)', schema_version: LATEST },
    employee,
    attendance_history: db.all('SELECT * FROM attendance WHERE employee_id=? ORDER BY work_date DESC', emp.id),
    work_sessions:      db.all('SELECT * FROM work_sessions WHERE employee_id=? ORDER BY work_date DESC', emp.id),
    leave_requests:     db.all('SELECT * FROM leave_requests WHERE employee_id=? ORDER BY submitted_at DESC', emp.id),
    chat_queries:       db.all('SELECT * FROM chat_queries WHERE employee_id=? ORDER BY id DESC LIMIT 1000', emp.id),
    inactivity_alerts:  db.all('SELECT * FROM inactivity_alerts WHERE employee_id=? ORDER BY alert_time DESC', emp.id)
  };
  fs.mkdirSync(config.dirs.removed, { recursive: true });
  fs.writeFileSync(path.join(config.dirs.removed, filename), JSON.stringify(dossier, null, 2), 'utf8');

  db.tx(() => {
    db.run('DELETE FROM breaks WHERE session_id IN (SELECT id FROM work_sessions WHERE employee_id=?)', emp.id);
    for (const t of ['work_sessions', 'attendance', 'leave_requests', 'chat_queries', 'chat_history', 'inactivity_alerts', 'sessions']) {
      db.run(`DELETE FROM ${t} WHERE employee_id=?`, emp.id);
    }
    db.run('DELETE FROM employees WHERE id=?', emp.id);
  });
  logUserChange('REMOVED', emp, actor, filename, reason);
  return filename;
}

module.exports = { archiveAndRemove, logUserChange };
