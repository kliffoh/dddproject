'use strict';
/**
 * Configuration is resolved once, validated, and frozen.
 * Precedence: real environment variables  >  .env file  >  defaults.
 * A tiny built-in .env parser keeps the dependency surface at zero.
 */
const fs   = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

(function loadDotEnv() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const i = line.indexOf('=');
    if (i < 1) continue;
    const key = line.slice(0, i).trim();
    let val = line.slice(i + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
    if (process.env[key] === undefined) process.env[key] = val;
  }
})();

const env  = (k, d = '') => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : d);
const int  = (k, d) => { const n = parseInt(env(k, String(d)), 10); return Number.isFinite(n) ? n : d; };
const bool = (k, d) => { const v = env(k, d ? '1' : '0').toLowerCase(); return v === '1' || v === 'true' || v === 'yes'; };

const BASE_DIR = path.resolve(env('DDD_DATA_DIR',
  path.join(process.env.APPDATA || process.env.HOME || ROOT, 'DDD_WorkforceSystem')));

const config = Object.freeze({
  version: '6.0.0',
  root: ROOT,
  publicDir: path.join(ROOT, 'public'),

  port: int('PORT', 8765),
  host: env('HOST', '0.0.0.0'),
  trustProxy: bool('TRUST_PROXY', false),
  publicUrl: env('PUBLIC_URL', '').replace(/\/+$/, ''),
  allowedOrigins: env('ALLOWED_ORIGINS', '').split(',').map(s => s.trim().replace(/\/+$/, '')).filter(Boolean),

  maxEmployees: int('DDD_MAX_EMPLOYEES', 550),

  // Per-IP flood guards. A whole office usually shares ONE public IP (NAT), so these
  // are sized for 550 people at once; brute force is stopped per account instead.
  rate: {
    apiBurst: int('RATE_API_BURST', 6000), apiPerSec: int('RATE_API_PER_SEC', 300),
    loginBurst: int('RATE_LOGIN_BURST', 700), loginPerSec: int('RATE_LOGIN_PER_SEC', 15)
  },

  sessionTtlMs: int('SESSION_TTL_HOURS', 12) * 3600 * 1000,
  superId: env('SUPER_ADMIN_ID', 'DEV-001').toUpperCase(),
  superPassOverride: env('SUPER_ADMIN_PASS', ''),
  seedDemo: bool('DDD_SEED_DEMO', true),
  logGeneratedPasswords: bool('DDD_LOG_GENERATED_PASSWORDS', false),

  inactivityMs: int('INACTIVITY_MIN', 45) * 60 * 1000,
  backupEveryMs: int('BACKUP_EVERY_HOURS', 1) * 3600 * 1000,
  backupKeep: int('BACKUP_KEEP', 48),

  anthropicKey: env('ANTHROPIC_API_KEY', ''),
  anthropicModel: env('ANTHROPIC_MODEL', 'claude-haiku-4-5-20251001'),

  workTargetS: 8 * 3600,
  breakStdS: 3600,

  dirs: {
    base: BASE_DIR,
    db: path.join(BASE_DIR, 'database'),
    logs: path.join(BASE_DIR, 'logs'),
    backups: path.join(BASE_DIR, 'backups'),
    removed: path.join(BASE_DIR, 'removed_employees'),
    changes: path.join(BASE_DIR, 'user_changes'),
    system: path.join(BASE_DIR, 'system')
  }
});

module.exports = config;
