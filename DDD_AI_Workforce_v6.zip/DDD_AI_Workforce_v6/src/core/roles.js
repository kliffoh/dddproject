'use strict';
const ROLE_RANK = Object.freeze({ Employee: 1, Supervisor: 2, Manager: 3, Admin: 4, SuperAdmin: 5 });
const ROLES = Object.keys(ROLE_RANK);
const SUPERVISORS = Object.freeze(['Supervisor', 'Manager', 'Admin', 'SuperAdmin']);
const isSupervisor = (role) => SUPERVISORS.includes(role);
const outranks = (actorRole, targetRole) => (ROLE_RANK[actorRole] || 0) > (ROLE_RANK[targetRole] || 99);
module.exports = { ROLE_RANK, ROLES, SUPERVISORS, isSupervisor, outranks };
