'use strict';
/**
 * Buffered, append-only daily log files.
 * Writes are batched and flushed every second (or on shutdown) so that
 * 550 concurrent users never trigger one synchronous disk write per event.
 */
const fs   = require('fs');
const path = require('path');
const config = require('../config');
const { today, eat } = require('./time');

const buffers = new Map();   // absolute file path -> string[]

function append(category, line) {
  const file = path.join(config.dirs.logs, category, `${category}_${today()}.txt`);
  if (!buffers.has(file)) buffers.set(file, []);
  buffers.get(file).push(`[${eat()}]  ${line}\n`);
}

function flush() {
  for (const [file, lines] of buffers) {
    if (!lines.length) continue;
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.appendFileSync(file, lines.join(''), 'utf8');
    } catch (e) { console.error('[logger] flush failed:', e.message); }
    lines.length = 0;
  }
}
const timer = setInterval(flush, 1000);
timer.unref();

const log = {
  event:  (u, a, d = '') => append('events', `${u} | ${a} | ${d}`),
  audit:  (u, a, d = '') => append('audit', `${u} | ${a} | ${d}`),
  login:  (u, ok, ip)    => append('logins', `${ok ? 'OK  ' : 'FAIL'} | ${u} | ${ip}`),
  chat:   (u, q, meta)   => append('chat', `${u} | lang=${meta.language} | intent=${meta.intent} | conf=${meta.confidence} | Q: ${String(q).slice(0, 120)}`),
  alert:  (u, mins)      => append('alerts', `${u} | inactive ${mins} min`),
  info:   (msg)          => { console.log(`  ${msg}`); append('events', `SYSTEM | ${msg}`); },
  error:  (ctx, e)       => {
    const msg = (e && (e.stack || e.message)) || String(e);
    append('errors', `ERROR | ${ctx} | ${msg}`);
    console.error(`[ERR] ${ctx}:`, (e && e.message) || e);
  },
  flush
};

module.exports = log;
