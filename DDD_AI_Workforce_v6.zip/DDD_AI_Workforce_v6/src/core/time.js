'use strict';
/** East Africa Time helpers. All persisted timestamps are ISO-8601 with +03:00. */
const TZ = 'Africa/Nairobi';

const now   = () => new Date().toLocaleString('sv-SE', { timeZone: TZ }).replace(' ', 'T') + '+03:00';
const today = () => new Date().toLocaleDateString('sv-SE', { timeZone: TZ });
const dayOffset = (days) => new Date(Date.now() + days * 86400000).toLocaleDateString('sv-SE', { timeZone: TZ });
const eat   = () => new Date().toLocaleString('en-KE', {
  timeZone: TZ, weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  hour: '2-digit', minute: '2-digit', second: '2-digit'
});
const isoAgo = (ms) => new Date(Date.now() - ms).toLocaleString('sv-SE', { timeZone: TZ }).replace(' ', 'T') + '+03:00';
const fileStamp = () => now().replace(/[:+]/g, '-').substring(0, 19);
const secondsSince = (iso) => Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));

module.exports = { TZ, now, today, dayOffset, eat, isoAgo, fileStamp, secondsSince };
