'use strict';
/** Typed HTTP errors + an async wrapper so every route funnels into one error handler. */
class HttpError extends Error {
  constructor(status, message, extra) { super(message); this.status = status; this.extra = extra; }
}
const bad       = (m) => new HttpError(400, m);
const forbidden = (m = 'You do not have permission to do that.') => new HttpError(403, m);
const notFound  = (m = 'Not found.') => new HttpError(404, m);
const conflict  = (m) => new HttpError(409, m);

const wrap = (fn) => (req, res, next) => {
  try {
    const r = fn(req, res, next);
    if (r && typeof r.catch === 'function') r.catch(next);
  } catch (e) { next(e); }
};

/** Small declarative validator — returns a clean value or throws 400. */
function str(value, name, { required = false, max = 200, min = 0, pattern = null, oneOf = null } = {}) {
  const v = value === undefined || value === null ? '' : String(value).trim();
  if (!v) { if (required) throw bad(`${name} is required.`); return ''; }
  if (v.length < min) throw bad(`${name} must be at least ${min} characters.`);
  if (v.length > max) throw bad(`${name} must be at most ${max} characters.`);
  if (pattern && !pattern.test(v)) throw bad(`${name} has an invalid format.`);
  if (oneOf && !oneOf.includes(v)) throw bad(`${name} must be one of: ${oneOf.join(', ')}.`);
  return v;
}

const ID_RE = /^[A-Z0-9][A-Z0-9-]{1,23}$/;

module.exports = { HttpError, bad, forbidden, notFound, conflict, wrap, str, ID_RE };
