'use strict';
const db = require('../db/database');
const sessions = require('../security/sessions');
const log = require('../core/logger');
const { now } = require('../core/time');
const { SUPERVISORS } = require('../core/roles');

const COOKIE = 'DDD_SESSION';

function readCookie(req, name) {
  const header = req.headers.cookie || '';
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return null;
}

function setSessionCookie(req, res, token, maxAgeMs) {
  const secure = req.secure ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${COOKIE}=${encodeURIComponent(token)}; Max-Age=${Math.floor(maxAgeMs / 1000)}; Path=/; HttpOnly; SameSite=Lax${secure}`);
}
const clearSessionCookie = (res) => res.setHeader('Set-Cookie', `${COOKIE}=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax`);

const tokenOf = (req) => req.headers['x-ddd-session'] || readCookie(req, COOKIE);

function auth(req, res, next) {
  const token = tokenOf(req);
  const empId = sessions.resolve(token);
  if (!empId) return res.status(401).json({ error: 'Your session has expired. Please sign in again.' });
  const emp = db.get('SELECT * FROM employees WHERE id=? AND active=1', empId);
  if (!emp) { sessions.destroy(token); clearSessionCookie(res); return res.status(401).json({ error: 'Account not available.' }); }
  req.emp = emp;
  req.token = token;
  next();
}

const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.emp.role) ? next() : res.status(403).json({ error: `This action requires: ${roles.join(' / ')}.` });

const supervisorOnly = requireRole(...SUPERVISORS);

function audit(actor, action, detail = '', ip = '') {
  try { db.run('INSERT INTO audit_log(actor_id,action,details,ip_address,created_at) VALUES(?,?,?,?,?)', actor, action, String(detail).slice(0, 500), ip, now()); }
  catch (e) { log.error('audit', e); }
  log.audit(actor, action, detail);
}

/** Strip secrets before sending an employee row to the client. */
function publicEmployee(e) {
  if (!e) return null;
  const { pwh, failed_logins, locked_until_ms, ...rest } = e;
  return rest;
}

module.exports = { auth, requireRole, supervisorOnly, audit, publicEmployee, setSessionCookie, clearSessionCookie, tokenOf };
