'use strict';
/**
 * WebSocket gateway.
 *  • Origin check on upgrade (prevents cross-site WebSocket hijacking).
 *  • Protocol-level ping/pong every 30 s; dead sockets (laptop lid closed,
 *    Wi-Fi dropped) are terminated instead of lingering as "online" forever.
 *  • Per-socket message budget and 8 KB payload cap.
 */
const WebSocket = require('ws');
const db = require('../db/database');
const sessions = require('../security/sessions');
const presence = require('../services/presence');
const { originAllowed } = require('../security/headers');

function attach(server) {
  const wss = new WebSocket.Server({
    server, path: '/ws', maxPayload: 8 * 1024, perMessageDeflate: false,
    verifyClient: ({ origin, req }) => originAllowed(origin, req)
  });

  wss.on('connection', (ws) => {
    ws.isAlive = true;
    ws.empId = null;
    ws.budget = { n: 0, t: Date.now() };
    ws.on('pong', () => { ws.isAlive = true; });

    const regTimer = setTimeout(() => { if (!ws.empId) ws.close(4000, 'Register timeout'); }, 15000);

    ws.on('message', (raw) => {
      const t = Date.now();
      if (t - ws.budget.t > 10000) ws.budget = { n: 0, t };
      if (++ws.budget.n > 30) return;                              // silently drop floods
      let m; try { m = JSON.parse(raw.toString()); } catch (_) { return; }

      if (m.type === 'REGISTER') {
        const empId = sessions.resolve(m.token);
        const emp = empId && db.get('SELECT id,name,role,department FROM employees WHERE id=? AND active=1', empId);
        if (!emp) { ws.send(JSON.stringify({ type: 'ERROR', error: 'Invalid session' })); return ws.close(4001, 'Invalid session'); }
        clearTimeout(regTimer);
        ws.empId = emp.id;
        const open = db.get("SELECT status FROM work_sessions WHERE employee_id=? AND status IN ('WORKING','BREAK') ORDER BY id DESC LIMIT 1", emp.id);
        const first = presence.add(emp, ws);
        if (open) presence.setStatus(emp.id, open.status);
        if (first) presence.toSupervisors({ type: 'EMPLOYEE_ONLINE', employeeId: emp.id, name: emp.name });
        ws.send(JSON.stringify({ type: 'REGISTERED', employeeId: emp.id }));
        return;
      }
      if (!ws.empId) return;
      if (m.type === 'HEARTBEAT' || m.type === 'STATUS_UPDATE') {
        const allowed = ['ONLINE', 'WORKING', 'BREAK', 'COMPLETED', 'IDLE'];
        const status = allowed.includes(m.status) ? m.status : null;
        // v5 bug: every heartbeat reset lastActivity to "now", so an open tab could
        // never trigger an inactivity alert. Use the client's real input idle time
        // (a duration, so it is immune to clock skew between PCs and the server).
        let idleMs = Number(m.idleMs);
        if (!Number.isFinite(idleMs) && Number.isFinite(m.lastActivity)) idleMs = Date.now() - m.lastActivity;
        idleMs = Number.isFinite(idleMs) ? Math.min(Math.max(0, idleMs), 24 * 3600000) : 0;
        const changed = presence.touch(ws.empId, status, Date.now() - idleMs);
        if (changed) presence.toSupervisors({ type: 'STATUS_CHANGE', employeeId: ws.empId, status, name: changed.name });
      }
    });

    ws.on('close', () => {
      clearTimeout(regTimer);
      if (ws.empId && presence.remove(ws.empId, ws)) presence.toSupervisors({ type: 'EMPLOYEE_OFFLINE', employeeId: ws.empId });
    });
    ws.on('error', () => {});
  });

  const pinger = setInterval(() => {
    for (const ws of wss.clients) {
      if (!ws.isAlive) { ws.terminate(); continue; }
      ws.isAlive = false;
      try { ws.ping(); } catch (_) {}
    }
  }, 30000);
  pinger.unref();

  return wss;
}

module.exports = { attach };
