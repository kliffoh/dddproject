'use strict';
/** Express application assembly: security → parsing → static → API → errors. */
const express = require('express');
const path = require('path');
const fs = require('fs');
const config = require('./config');
const log = require('./core/logger');
const db = require('./db/database');
const presence = require('./services/presence');
const { securityHeaders, cors } = require('./security/headers');
const { limiter } = require('./security/rate-limit');
const { now, eat } = require('./core/time');

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy ? 1 : false);   // correct client IPs behind Caddy/Cloudflare/Render

  app.use(securityHeaders);
  app.use(cors);

  // Liveness & readiness — used by Docker, Render, Fly and the hosting scripts.
  app.get('/api/health', (req, res) => res.json({ ok: true, version: config.version, time: now(), eat: eat(), online: presence.size }));
  app.get('/api/ready', (req, res) => {
    try { db.get('SELECT 1'); res.json({ ready: true }); }
    catch (e) { res.status(503).json({ ready: false }); }
  });

  // Flood guard: generous per-IP because a whole office may share one NAT address.
  app.use('/api/', limiter({ capacity: config.rate.apiBurst, refillPerSec: config.rate.apiPerSec, key: (req) => `ip:${req.ip}` }));
  app.use('/api/login', limiter({ capacity: config.rate.loginBurst, refillPerSec: config.rate.loginPerSec, key: (req) => `login:${req.ip}` }));
  app.use(express.json({ limit: '1mb' }));

  // Only /public is served. v5 served the whole application folder (server.js,
  // package.json, and any data directory placed beside it).
  const indexHtml = path.join(config.publicDir, 'index.html');
  app.use(express.static(config.publicDir, {
    index: false, etag: true, maxAge: '1h',
    setHeaders: (res, file) => { if (file.endsWith('.html') || file.endsWith('config.js')) res.setHeader('Cache-Control', 'no-cache'); }
  }));
  app.get('/', (req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.sendFile(indexHtml); });

  app.use('/api', require('./routes/auth'));
  app.use('/api', require('./routes/work'));
  app.use('/api/leave', require('./routes/leave'));
  app.use('/api/chat', require('./routes/chat'));
  app.use('/api/notes', require('./routes/notes'));
  app.use('/api/users', require('./routes/users'));
  app.use('/api', require('./routes/admin'));

  app.use('/api', (req, res) => res.status(404).json({ error: `No such endpoint: ${req.method} ${req.originalUrl}` }));
  app.get('*', (req, res) => (fs.existsSync(indexHtml) ? res.sendFile(indexHtml) : res.status(404).end()));

  // Central error handler — never leaks stack traces to clients.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON body.' });
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request too large.' });
    const status = err.status && err.status < 600 ? err.status : 500;
    if (status >= 500) log.error(`${req.method} ${req.originalUrl}`, err);
    if (res.headersSent) return res.end();
    res.status(status).json({ error: status >= 500 ? 'Internal server error. The incident has been logged.' : err.message });
  });

  return app;
}

module.exports = { createApp };
