'use strict';
/** Background jobs: inactivity alerts, session sweep, data retention, hot backups. */
const fs = require('fs');
const path = require('path');
const db = require('../db/database');
const config = require('../config');
const log = require('../core/logger');
const presence = require('../services/presence');
const sessions = require('../security/sessions');
const { now, isoAgo, fileStamp } = require('../core/time');

function inactivityCheck() {
  const t = Date.now();
  const repeatMs = Math.max(config.inactivityMs, 15 * 60 * 1000);
  for (const [id, u] of presence.online) {
    if (u.status !== 'WORKING') continue;
    const idle = t - u.lastActivity;
    if (idle < config.inactivityMs || (u.lastAlertAt && t - u.lastAlertAt < repeatMs)) continue;
    const mins = Math.floor(idle / 60000);
    try {
      db.run('INSERT INTO inactivity_alerts(employee_id,alert_time,duration_minutes) VALUES(?,?,?)', id, now(), mins);
      u.lastAlertAt = t;
      log.alert(id, mins);
      presence.toSupervisors({ type: 'INACTIVITY_ALERT', employeeId: id, name: u.name, department: u.dept, minutes: mins });
    } catch (e) { log.error('inactivity', e); }
  }
}

function retention() {
  const cut30 = isoAgo(30 * 86400000), cut365 = isoAgo(365 * 86400000);
  const a = db.run('DELETE FROM chat_history WHERE created_at < ?', cut30).changes;
  const b = db.run('DELETE FROM inactivity_alerts WHERE acknowledged=1 AND alert_time < ?', cut365).changes;
  const c = sessions.sweep();
  if (a + b + c) log.info(`Retention: ${a} chat turns, ${b} old alerts, ${c} expired sessions removed`);
}

function backup() {
  try {
    fs.mkdirSync(config.dirs.backups, { recursive: true });
    const file = path.join(config.dirs.backups, `backup_${fileStamp()}.sqlite3`);
    db.backupTo(file);                                   // VACUUM INTO: consistent, online, compact
    const files = fs.readdirSync(config.dirs.backups).filter(f => f.startsWith('backup_') && f.endsWith('.sqlite3')).sort();
    for (const f of files.slice(0, Math.max(0, files.length - config.backupKeep))) fs.unlinkSync(path.join(config.dirs.backups, f));
    log.event('SYSTEM', 'BACKUP', path.basename(file));
  } catch (e) { log.error('backup', e); }
}

const timers = [];
function start() {
  const every = (ms, fn) => { const h = setInterval(() => { try { fn(); } catch (e) { log.error(fn.name, e); } }, ms); h.unref(); timers.push(h); };
  every(60 * 1000, inactivityCheck);
  every(6 * 3600 * 1000, retention);
  if (config.backupEveryMs > 0) every(config.backupEveryMs, backup);
  setTimeout(retention, 10000).unref();
  setTimeout(backup, 60000).unref();                     // first backup a minute after boot
}
const stop = () => timers.forEach(clearInterval);

module.exports = { start, stop, backup };
