'use strict';
const express = require('express');
const db = require('../db/database');
const config = require('../config');
const log = require('../core/logger');
const presence = require('../services/presence');
const { now, today, dayOffset, secondsSince } = require('../core/time');
const { wrap, bad } = require('../core/http-error');
const { auth, supervisorOnly, publicEmployee } = require('../http/middleware');
const { isSupervisor } = require('../core/roles');

const router = express.Router();
router.use(auth);

const sessionById = (id) => db.get('SELECT * FROM work_sessions WHERE id=?', id);
const openSession = (uid, statuses) =>
  db.get(`SELECT * FROM work_sessions WHERE employee_id=? AND work_date=? AND status IN (${statuses.map(() => '?').join(',')}) ORDER BY id DESC LIMIT 1`,
    uid, today(), ...statuses);

function closeOpenBreak(sessionId) {
  const br = db.get('SELECT * FROM breaks WHERE session_id=? AND ended_at IS NULL ORDER BY id DESC LIMIT 1', sessionId);
  if (!br) return 0;
  const d = secondsSince(br.started_at);
  db.run('UPDATE breaks SET ended_at=?, duration_seconds=? WHERE id=?', now(), d, br.id);
  return d;
}

function announce(emp, status) {
  presence.setStatus(emp.id, status);
  presence.toSupervisors({ type: 'STATUS_CHANGE', employeeId: emp.id, name: emp.name, status });
  log.event(emp.id, `WORK_${status}`);
}

/** Upcoming birthdays within N days, computed on month-day (year-agnostic). */
function upcomingBirthdays(days = 14) {
  const window = new Set(Array.from({ length: days + 1 }, (_, i) => dayOffset(i).slice(5)));
  return db.all("SELECT id,name,department,birthday,avatar_initials FROM employees WHERE active=1 AND birthday<>''")
    .filter(e => window.has(String(e.birthday).slice(5, 10)))
    .sort((a, b) => a.birthday.slice(5).localeCompare(b.birthday.slice(5)));
}

router.get('/dashboard', (req, res) => {
  const uid = req.emp.id, d = today();
  const attendance = db.get('SELECT * FROM attendance WHERE employee_id=? AND work_date=?', uid, d);
  const session = db.get('SELECT * FROM work_sessions WHERE employee_id=? AND work_date=? ORDER BY id DESC LIMIT 1', uid, d);
  const breaks = session ? db.all('SELECT * FROM breaks WHERE session_id=? ORDER BY id', session.id) : [];
  const dayTotals = db.get(`SELECT COALESCE(SUM(active_seconds),0) AS active_s, COALESCE(SUM(break_seconds),0) AS break_s, COUNT(*) AS sessions
                            FROM work_sessions WHERE employee_id=? AND work_date=? AND status='COMPLETED'`, uid, d);
  let stats = null;
  if (isSupervisor(req.emp.role)) {
    stats = {
      total_employees: db.get('SELECT COUNT(*) AS c FROM employees WHERE active=1').c,
      capacity: config.maxEmployees,
      online_now: presence.size,
      present_today: db.get('SELECT COUNT(*) AS c FROM attendance WHERE work_date=?', d).c,
      pending_leaves: db.get("SELECT COUNT(*) AS c FROM leave_requests WHERE status='Pending'").c,
      active_alerts: db.get('SELECT COUNT(*) AS c FROM inactivity_alerts WHERE acknowledged=0').c,
      upcoming_birthdays: upcomingBirthdays()
    };
  }
  res.json({ employee: publicEmployee(req.emp), attendance, session, breaks, day_totals: dayTotals, stats });
});

// ─── Work session state machine:  IDLE → WORKING ⇄ BREAK → COMPLETED ───────
router.post('/start', (req, res) => {
  const cur = openSession(req.emp.id, ['WORKING', 'BREAK']);
  if (cur && cur.status === 'BREAK') {
    const d = closeOpenBreak(cur.id);
    db.run("UPDATE work_sessions SET status='WORKING', break_seconds=break_seconds+? WHERE id=?", d, cur.id);
    announce(req.emp, 'WORKING');
    return res.json(sessionById(cur.id));
  }
  if (cur) return res.json(cur);
  const id = db.run("INSERT INTO work_sessions(employee_id,work_date,started_at,status) VALUES(?,?,?,'WORKING')", req.emp.id, today(), now()).lastInsertRowid;
  announce(req.emp, 'WORKING');
  res.json(sessionById(id));
});

router.post('/break', wrap((req, res) => {
  const s = openSession(req.emp.id, ['WORKING']);
  if (!s) throw bad('Start work first.');
  db.tx(() => {
    db.run("UPDATE work_sessions SET status='BREAK' WHERE id=?", s.id);
    db.run('INSERT INTO breaks(session_id,started_at) VALUES(?,?)', s.id, now());
  });
  announce(req.emp, 'BREAK');
  res.json(sessionById(s.id));
}));

router.post('/resume', wrap((req, res) => {
  const s = openSession(req.emp.id, ['BREAK']);
  if (!s) throw bad('No active break.');
  db.tx(() => {
    const d = closeOpenBreak(s.id);
    db.run("UPDATE work_sessions SET status='WORKING', break_seconds=break_seconds+? WHERE id=?", d, s.id);
  });
  announce(req.emp, 'WORKING');
  res.json(sessionById(s.id));
}));

router.post('/stop', wrap((req, res) => {
  const s = openSession(req.emp.id, ['WORKING', 'BREAK']);
  if (!s) throw bad('No active session.');
  db.tx(() => {
    const total = secondsSince(s.started_at);
    const brk = s.break_seconds + (s.status === 'BREAK' ? closeOpenBreak(s.id) : 0);
    const active = Math.max(0, total - brk);
    db.run("UPDATE work_sessions SET ended_at=?, active_seconds=?, break_seconds=?, overtime_seconds=?, status='COMPLETED' WHERE id=?",
      now(), active, brk, Math.max(0, active - config.workTargetS), s.id);
    db.run("UPDATE attendance SET logout_time=?, status='Completed' WHERE employee_id=? AND work_date=?", now(), req.emp.id, today());
  });
  announce(req.emp, 'COMPLETED');
  res.json(sessionById(s.id));
}));

// ─── Attendance records (paginated for 550+ employees) ──────────────────────
function recordFilters(q) {
  const where = [], params = [];
  if (q.from) { where.push('a.work_date >= ?'); params.push(String(q.from).slice(0, 10)); }
  if (q.to)   { where.push('a.work_date <= ?'); params.push(String(q.to).slice(0, 10)); }
  if (q.department) { where.push('e.department = ?'); params.push(String(q.department).slice(0, 60)); }
  if (q.q) { where.push('(e.name LIKE ? OR e.id LIKE ?)'); const like = `%${String(q.q).slice(0, 40)}%`; params.push(like, like); }
  return { where, params };
}

router.get('/records', (req, res) => {
  const limit = Math.min(2000, Math.max(1, parseInt(req.query.limit, 10) || 500));
  const offset = Math.max(0, parseInt(req.query.offset, 10) || 0);
  const cols = `a.*, e.name, e.department, e.id AS employee_id, e.job_title, e.tracking_number AS tracking_ref`;
  if (!isSupervisor(req.emp.role)) {
    return res.json({ items: db.all(`SELECT ${cols} FROM attendance a JOIN employees e ON e.id=a.employee_id
                                      WHERE a.employee_id=? ORDER BY a.work_date DESC LIMIT 90`, req.emp.id) });
  }
  const { where, params } = recordFilters(req.query);
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db.get(`SELECT COUNT(*) AS c FROM attendance a JOIN employees e ON e.id=a.employee_id ${w}`, ...params).c;
  const items = db.all(`SELECT ${cols} FROM attendance a JOIN employees e ON e.id=a.employee_id ${w}
                        ORDER BY a.work_date DESC, e.name LIMIT ? OFFSET ?`, ...params, limit, offset);
  res.json({ items, total, limit, offset });
});

// CSV with formula-injection protection (cells starting with = + - @ are neutralised)
const csvCell = (v) => {
  let s = v === null || v === undefined ? '' : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

router.get('/export.csv', supervisorOnly, (req, res) => {
  const { where, params } = recordFilters(req.query);
  const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const rows = db.all(`SELECT a.work_date, e.id, e.name, e.department, e.job_title, a.login_time, a.logout_time, a.status,
                         (SELECT COALESCE(SUM(active_seconds),0) FROM work_sessions s WHERE s.employee_id=a.employee_id AND s.work_date=a.work_date) AS active_s,
                         (SELECT COALESCE(SUM(break_seconds),0) FROM work_sessions s WHERE s.employee_id=a.employee_id AND s.work_date=a.work_date) AS break_s,
                         (SELECT COALESCE(SUM(overtime_seconds),0) FROM work_sessions s WHERE s.employee_id=a.employee_id AND s.work_date=a.work_date) AS overtime_s
                       FROM attendance a JOIN employees e ON e.id=a.employee_id ${w} ORDER BY a.work_date DESC, e.name LIMIT 100000`, ...params);
  const header = ['Date', 'Employee ID', 'Name', 'Department', 'Job Title', 'Clock In', 'Clock Out', 'Status', 'Active Hours', 'Break Hours', 'Overtime Hours'];
  const h = (s) => (s / 3600).toFixed(2);
  const body = rows.map(r => [r.work_date, r.id, r.name, r.department, r.job_title, r.login_time, r.logout_time, r.status, h(r.active_s), h(r.break_s), h(r.overtime_s)].map(csvCell).join(','));
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="ddd_attendance_${today()}.csv"`);
  res.send('\uFEFF' + [header.join(','), ...body].join('\r\n'));
});

router.get('/insights', (req, res) => {
  const since = dayOffset(-30);
  const agg = db.get(`SELECT COUNT(*) AS n, COALESCE(SUM(active_seconds),0) AS a, COALESCE(SUM(break_seconds),0) AS b, COALESCE(SUM(overtime_seconds),0) AS o
                      FROM work_sessions WHERE employee_id=? AND status='COMPLETED' AND work_date>=?`, req.emp.id, since);
  const daily = db.all(`SELECT work_date AS date, ROUND(SUM(active_seconds)/3600.0,1) AS active_h, ROUND(SUM(overtime_seconds)/3600.0,1) AS ot_h
                        FROM work_sessions WHERE employee_id=? AND status='COMPLETED' AND work_date>=? GROUP BY work_date ORDER BY work_date DESC LIMIT 14`, req.emp.id, since);
  const dept = isSupervisor(req.emp.role)
    ? db.all(`SELECT e.department, ROUND(AVG(day_active)) AS avg_active FROM (
                SELECT employee_id, work_date, SUM(active_seconds) AS day_active FROM work_sessions
                WHERE status='COMPLETED' AND work_date>=? GROUP BY employee_id, work_date) t
              JOIN employees e ON e.id=t.employee_id GROUP BY e.department ORDER BY avg_active DESC`, since)
    : [];
  const r1 = (s) => +(s / 3600).toFixed(1);
  res.json({ completed_shifts: agg.n, active_hours: r1(agg.a), break_hours: r1(agg.b), overtime_hours: r1(agg.o), daily, dept_breakdown: dept });
});

module.exports = router;
