'use strict';
const express = require('express');
const db = require('../db/database');
const engine = require('../services/chat/engine');
const presence = require('../services/presence');
const { limiter } = require('../security/rate-limit');
const { isoAgo } = require('../core/time');
const { wrap, str, bad, notFound } = require('../core/http-error');
const { auth, supervisorOnly, audit } = require('../http/middleware');

const router = express.Router();
router.use(auth);

// 20-message burst, then one message every 3 s per employee.
const chatLimit = limiter({ capacity: 20, refillPerSec: 1 / 3, key: (req) => `chat:${req.emp.id}` });

function readMessage(req) {
  return str(req.body.message, 'Message', { required: true, max: 2000 });
}

function notifySupervisors(emp, message, r) {
  presence.toSupervisors({ type: 'CHAT_QUERY', employeeId: emp.id, employeeName: emp.name, query: message.slice(0, 200),
    intent: r.intent, confidence: r.confidence, language: r.language });
}

/** JSON (non-streaming) endpoint — kept for API clients and backwards compatibility. */
router.post('/', chatLimit, wrap(async (req, res) => {
  const message = readMessage(req);
  const r = await engine.answer(req.emp, message);
  notifySupervisors(req.emp, message, r);
  res.json(r);
}));

/**
 * Server-Sent Events stream:
 *   event: meta   {intent, language, keywords}     — as soon as the query is understood
 *   event: delta  {text}                           — answer tokens as they are produced
 *   event: done   {id, confidence, sources, suggestions, …}
 */
router.post('/stream', chatLimit, wrap(async (req, res) => {
  const message = readMessage(req);
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no'                // disable proxy buffering (nginx)
  });
  let open = true;
  res.on('close', () => { open = false; });     // NB: req 'close' fires once the body is read, not on disconnect
  const send = (event, data) => { if (open) res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); };
  let streamed = false;

  try {
    const r = await engine.answer(req.emp, message, {
      onMeta: (m) => send('meta', m),
      onDelta: (t) => { streamed = true; send('delta', { text: t }); }
    });
    if (!streamed) {
      // Retrieval answers are ready instantly; deliver them in word groups so
      // the UI renders progressively (~250 ms total, never artificially slow).
      const words = r.response.split(/(\s+)/);
      const step = Math.max(6, Math.ceil(words.length / 12));
      for (let i = 0; i < words.length && open; i += step) {
        send('delta', { text: words.slice(i, i + step).join('') });
        await new Promise(ok => setTimeout(ok, 18));
      }
    }
    const { response, ...meta } = r;
    send('done', meta);
    notifySupervisors(req.emp, message, r);
  } catch (e) {
    send('error', { error: 'The assistant hit a problem. Please try again.' });
    throw e;
  } finally {
    if (open) res.end();
  }
}));

router.get('/history', (req, res) => {
  const items = db.all(`SELECT role, content, created_at FROM chat_history
                        WHERE employee_id=? AND created_at >= ? ORDER BY id DESC LIMIT 60`, req.emp.id, isoAgo(30 * 86400000)).reverse();
  res.json({ items });
});

router.delete('/history', (req, res) => {
  db.run('DELETE FROM chat_history WHERE employee_id=?', req.emp.id);
  res.json({ ok: true });
});

router.post('/feedback', wrap((req, res) => {
  const id = parseInt(req.body.id, 10);
  if (!id) throw bad('Query id required.');
  if (!engine.feedback(req.emp, id, Boolean(req.body.helpful))) throw notFound('Query not found.');
  res.json({ ok: true });
}));

// ─── Supervisor analytics & teaching ────────────────────────────────────────
router.get('/queries', supervisorOnly, (req, res) => {
  const limit = Math.min(1000, parseInt(req.query.limit, 10) || 300);
  res.json({ items: db.all(`SELECT cq.*, e.name, e.department FROM chat_queries cq JOIN employees e ON e.id=cq.employee_id
                            ORDER BY cq.id DESC LIMIT ?`, limit) });
});

router.get('/gaps', supervisorOnly, (req, res) => res.json(engine.gaps(Math.min(365, parseInt(req.query.days, 10) || 30))));

router.post('/teach', supervisorOnly, wrap((req, res) => {
  const id = parseInt(req.body.query_id, 10) || 0;
  const title = str(req.body.title, 'Title', { required: true, max: 120 });
  const content = str(req.body.content, 'Answer', { required: true, max: 4000 });
  const category = str(req.body.category, 'Category', { max: 40 }) || 'General';
  const noteId = engine.teach(req.emp.id, id, { title, content, category, intent: req.body.intent });
  audit(req.emp.id, 'BOT_TAUGHT', `query #${id} → note #${noteId}: ${title}`, req.ip);
  presence.toSupervisors({ type: 'NOTE_CHANGED', action: 'added', noteId, title });
  res.json({ ok: true, note_id: noteId });
}));

module.exports = router;
