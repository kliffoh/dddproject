'use strict';
const express = require('express');
const db = require('../db/database');
const presence = require('../services/presence');
const { now } = require('../core/time');
const { wrap, str, bad, forbidden, notFound } = require('../core/http-error');
const { auth, supervisorOnly, audit } = require('../http/middleware');
const { isSupervisor } = require('../core/roles');

const router = express.Router();
router.use(auth);

const TYPES = ['Annual', 'Sick', 'Maternity', 'Paternity', 'Compassionate', 'Study', 'Unpaid', 'Other'];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

router.get('/', (req, res) => {
  const sup = isSupervisor(req.emp.role);
  const status = req.query.status ? String(req.query.status) : null;
  const items = sup
    ? db.all(`SELECT l.*, e.name, e.department FROM leave_requests l JOIN employees e ON e.id=l.employee_id
              ${status ? 'WHERE l.status=?' : ''} ORDER BY l.submitted_at DESC LIMIT 1000`, ...(status ? [status] : []))
    : db.all(`SELECT l.*, e.name FROM leave_requests l JOIN employees e ON e.id=l.employee_id
              WHERE l.employee_id=? ORDER BY l.submitted_at DESC LIMIT 200`, req.emp.id);
  res.json({ items });
});

router.post('/', wrap((req, res) => {
  const b = req.body;
  // Accept free-form legacy labels like "Annual Leave" by matching the first word.
  const rawType = str(b.request_type, 'Leave type', { required: true, max: 40 });
  const type = TYPES.find(t => rawType.toLowerCase().startsWith(t.toLowerCase())) || 'Other';
  const start = str(b.start_date, 'Start date', { required: true, pattern: DATE_RE });
  const end = str(b.end_date, 'End date', { required: true, pattern: DATE_RE });
  if (end < start) throw bad('End date cannot be before the start date.');
  const reason = str(b.reason, 'Reason', { required: true, max: 1000 });
  const notes = str(b.notes, 'Notes', { max: 1000 });
  const id = db.run('INSERT INTO leave_requests(employee_id,request_type,start_date,end_date,reason,submitted_at) VALUES(?,?,?,?,?,?)',
    req.emp.id, rawType.length <= 40 ? rawType : type, start, end, notes ? `${reason}\n\nNotes: ${notes}` : reason, now()).lastInsertRowid;
  presence.toSupervisors({ type: 'LEAVE_REQUEST', employeeName: req.emp.name, requestType: rawType });
  res.json({ ok: true, id });
}));

router.post('/review', supervisorOnly, wrap((req, res) => {
  const id = parseInt(req.body.id, 10);
  const decision = str(req.body.decision, 'Decision', { required: true, oneOf: ['Approved', 'Rejected'] });
  const row = db.get('SELECT * FROM leave_requests WHERE id=?', id);
  if (!row) throw notFound('Leave request not found.');
  if (row.employee_id === req.emp.id) throw forbidden('You cannot review your own leave request.');
  if (row.status !== 'Pending') throw bad(`This request was already ${row.status.toLowerCase()}.`);
  db.run('UPDATE leave_requests SET status=?, reviewed_by=?, reviewed_at=? WHERE id=?', decision, req.emp.id, now(), id);
  audit(req.emp.id, `LEAVE_${decision.toUpperCase()}`, `#${id} for ${row.employee_id}`, req.ip);
  presence.toEmployee(row.employee_id, { type: 'LEAVE_DECISION', id, decision, requestType: row.request_type });
  res.json({ ok: true });
}));

module.exports = router;
