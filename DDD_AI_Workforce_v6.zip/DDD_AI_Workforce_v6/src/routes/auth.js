'use strict';
const express = require('express');
const db = require('../db/database');
const config = require('../config');
const log = require('../core/logger');
const password = require('../security/password');
const sessions = require('../security/sessions');
const presence = require('../services/presence');
const { now, today } = require('../core/time');
const { wrap, str, bad, ID_RE, HttpError } = require('../core/http-error');
const { auth, audit, publicEmployee, setSessionCookie, clearSessionCookie } = require('../http/middleware');

const router = express.Router();
const MAX_FAILS = 8, LOCK_MS = 15 * 60 * 1000;
const GENERIC = 'Invalid Employee ID or password.';
let dummyHash = null;                   // equalises timing for unknown IDs (no user enumeration)
password.hash('timing-equaliser').then(h => { dummyHash = h; });

router.post('/login', wrap(async (req, res) => {
  const uid = str(req.body.user_id, 'Employee ID', { required: true, max: 24 }).toUpperCase();
  const pw  = String(req.body.password || '');
  if (!pw) throw bad('Password is required.');

  const emp = ID_RE.test(uid) ? db.get('SELECT * FROM employees WHERE id=?', uid) : null;

  if (!emp || !emp.active) {
    await password.verify(pw, dummyHash);
    log.login(uid, false, req.ip); audit(uid, 'LOGIN_FAILED', emp ? 'disabled account' : 'unknown id', req.ip);
    throw new HttpError(401, GENERIC);
  }
  if (emp.locked_until_ms && emp.locked_until_ms > Date.now()) {
    const mins = Math.ceil((emp.locked_until_ms - Date.now()) / 60000);
    throw new HttpError(423, `Too many failed attempts. Account locked for ${mins} more minute(s), or ask an administrator to reset your password.`);
  }

  const { ok, needsRehash } = await password.verify(pw, emp.pwh);
  if (!ok) {
    const fails = (emp.failed_logins || 0) + 1;
    if (fails >= MAX_FAILS) {
      db.run('UPDATE employees SET failed_logins=0, locked_until_ms=? WHERE id=?', Date.now() + LOCK_MS, emp.id);
      audit(emp.id, 'ACCOUNT_LOCKED', `${MAX_FAILS} failed attempts`, req.ip);
    } else {
      db.run('UPDATE employees SET failed_logins=? WHERE id=?', fails, emp.id);
    }
    log.login(uid, false, req.ip); audit(uid, 'LOGIN_FAILED', 'wrong password', req.ip);
    throw new HttpError(401, GENERIC);
  }

  if (needsRehash) db.run('UPDATE employees SET pwh=? WHERE id=?', await password.hash(pw), emp.id);
  const token = sessions.create(emp.id, req.ip, req.headers['user-agent']);
  setSessionCookie(req, res, token, config.sessionTtlMs);
  db.run('UPDATE employees SET last_login=?, login_count=COALESCE(login_count,0)+1, failed_logins=0, locked_until_ms=0 WHERE id=?', now(), emp.id);
  db.run("INSERT OR IGNORE INTO attendance(employee_id,work_date,login_time,status) VALUES(?,?,?,'Present')", emp.id, today(), now());

  log.login(uid, true, req.ip); audit(emp.id, 'LOGIN_SUCCESS', '', req.ip); log.event(emp.id, 'LOGIN', `role=${emp.role}`);
  res.json({ token, employee: publicEmployee(db.get('SELECT * FROM employees WHERE id=?', emp.id)),
             work_target_s: config.workTargetS, break_std_s: config.breakStdS });
}));

router.post('/logout', auth, (req, res) => {
  sessions.destroy(req.token);
  audit(req.emp.id, 'LOGOUT', '', req.ip);
  clearSessionCookie(res);
  res.json({ ok: true });
});

/** Restores a session after a page refresh (token kept in sessionStorage). */
router.get('/me', auth, (req, res) => res.json({
  employee: publicEmployee(req.emp), work_target_s: config.workTargetS, break_std_s: config.breakStdS
}));

router.post('/me/password', auth, wrap(async (req, res) => {
  const current = String(req.body.current_password || '');
  const next = String(req.body.new_password || '');
  const { ok } = await password.verify(current, req.emp.pwh);
  if (!ok) throw bad('Current password is incorrect.');
  const problem = password.policy(next);
  if (problem) throw bad(problem);
  if (current === next) throw bad('New password must be different.');
  db.run('UPDATE employees SET pwh=? WHERE id=?', await password.hash(next), req.emp.id);
  sessions.destroyAllFor(req.emp.id, req.token);           // sign out other devices
  audit(req.emp.id, 'PASSWORD_CHANGED', 'self-service', req.ip);
  res.json({ ok: true });
}));

module.exports = router;
module.exports.kickSessions = (empId) => { sessions.destroyAllFor(empId); presence.kick(empId, 'Signed out by administrator'); };
