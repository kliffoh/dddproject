'use strict';
/** Monitoring (supervisors) and system administration (SuperAdmin). */
const express = require('express');
const fs = require('fs');
const db = require('../db/database');
const config = require('../config');
const presence = require('../services/presence');
const sessions = require('../security/sessions');
const { eat } = require('../core/time');
const { LATEST } = require('../db/migrations');
const { auth, supervisorOnly, requireRole } = require('../http/middleware');

const router = express.Router();
router.use(auth);

router.get('/online', supervisorOnly, (req, res) => res.json({ items: presence.list() }));

router.get('/alerts', supervisorOnly, (req, res) => res.json({ items: db.all(`
  SELECT ia.*, e.name, e.department FROM inactivity_alerts ia JOIN employees e ON e.id=ia.employee_id
  WHERE ia.acknowledged=0 ORDER BY ia.id DESC LIMIT 100`) }));

router.post('/alerts/:id/ack', supervisorOnly, (req, res) => {
  db.run('UPDATE inactivity_alerts SET acknowledged=1 WHERE id=?', parseInt(req.params.id, 10));
  res.json({ ok: true });
});

router.get('/user-changes', requireRole('SuperAdmin'), (req, res) =>
  res.json({ items: db.all('SELECT * FROM user_change_log ORDER BY id DESC LIMIT 1000') }));

router.get('/audit', requireRole('SuperAdmin'), (req, res) => res.json({ items: db.all(`
  SELECT al.*, e.name FROM audit_log al LEFT JOIN employees e ON e.id=al.actor_id ORDER BY al.id DESC LIMIT 1000`) }));

router.get('/system', requireRole('SuperAdmin'), (req, res) => {
  let dbBytes = 0; try { dbBytes = fs.statSync(db.path).size; } catch (_) {}
  res.json({
    version: config.version, schema: LATEST, node: process.version, platform: `${process.platform}/${process.arch}`,
    uptime_s: Math.floor(process.uptime()), active_sessions: sessions.count(), online_users: presence.size,
    employees_active: db.get('SELECT COUNT(*) AS c FROM employees WHERE active=1').c, capacity: config.maxEmployees,
    eat: eat(), work_target_s: config.workTargetS, break_std_s: config.breakStdS,
    db_path: db.path, db_size_mb: +(dbBytes / 1048576).toFixed(2), base_dir: config.dirs.base, log_dir: config.dirs.logs,
    acc_dir: config.dirs.backups, public_url: config.publicUrl || '(not set)', trust_proxy: config.trustProxy,
    ai: config.anthropicKey ? `Claude (${config.anthropicModel})` : 'Retrieval engine (no API key)',
    memory: process.memoryUsage()
  });
});

module.exports = router;
