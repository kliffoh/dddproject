'use strict';
/** Knowledge base CRUD. Every change invalidates the cached BM25 index. */
const express = require('express');
const db = require('../db/database');
const engine = require('../services/chat/engine');
const presence = require('../services/presence');
const { now } = require('../core/time');
const { wrap, str, notFound } = require('../core/http-error');
const { auth, supervisorOnly, audit } = require('../http/middleware');

const router = express.Router();
router.use(auth, supervisorOnly);

const fields = (b) => ({
  title: str(b.title, 'Title', { required: true, max: 120 }),
  content: str(b.content, 'Content', { required: true, max: 4000 }),
  category: str(b.category, 'Category', { max: 40 }) || 'General',
  language: str(b.language, 'Language', { max: 5 }) || 'multi'
});

router.get('/', (req, res) => res.json({ items: db.all(`
  SELECT n.*, COALESCE(s.served,0) AS served, COALESCE(s.helpful,0) AS helpful, COALESCE(s.unhelpful,0) AS unhelpful
  FROM chatbot_notes n LEFT JOIN note_stats s ON s.note_id=n.id ORDER BY n.id DESC`) }));

router.post('/', wrap((req, res) => {
  const f = fields(req.body);
  const id = db.run('INSERT INTO chatbot_notes(title,content,category,language,created_by,created_at) VALUES(?,?,?,?,?,?)',
    f.title, f.content, f.category, f.language, req.emp.id, now()).lastInsertRowid;
  engine.invalidate();
  audit(req.emp.id, 'NOTE_ADDED', f.title, req.ip);
  presence.toSupervisors({ type: 'NOTE_CHANGED', action: 'added', noteId: id, title: f.title });
  res.json({ ok: true, id });
}));

router.put('/:id', wrap((req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!db.get('SELECT id FROM chatbot_notes WHERE id=?', id)) throw notFound('Note not found.');
  const f = fields(req.body);
  db.run('UPDATE chatbot_notes SET title=?, content=?, category=?, language=? WHERE id=?', f.title, f.content, f.category, f.language, id);
  engine.invalidate();
  audit(req.emp.id, 'NOTE_UPDATED', f.title, req.ip);
  res.json({ ok: true });
}));

router.delete('/:id', wrap((req, res) => {
  const id = parseInt(req.params.id, 10);
  const row = db.get('SELECT title FROM chatbot_notes WHERE id=?', id);
  if (!row) throw notFound('Note not found.');
  db.tx(() => { db.run('DELETE FROM chatbot_notes WHERE id=?', id); db.run('DELETE FROM note_stats WHERE note_id=?', id); });
  engine.invalidate();
  audit(req.emp.id, 'NOTE_DELETED', row.title, req.ip);
  presence.toSupervisors({ type: 'NOTE_CHANGED', action: 'deleted', noteId: id, title: row.title });
  res.json({ ok: true });
}));

module.exports = router;
