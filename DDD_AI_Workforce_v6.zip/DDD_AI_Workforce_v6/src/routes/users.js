'use strict';
/** Employee administration with strict role hierarchy and seat capacity. */
const express = require('express');
const fs = require('fs');
const path = require('path');
const db = require('../db/database');
const config = require('../config');
const password = require('../security/password');
const presence = require('../services/presence');
const { archiveAndRemove, logUserChange } = require('../services/archive');
const { initials, tracking } = require('../db/seed');
const { kickSessions } = require('./auth');
const { now, eat, today } = require('../core/time');
const { wrap, str, bad, forbidden, notFound, conflict, ID_RE } = require('../core/http-error');
const { auth, requireRole, audit } = require('../http/middleware');
const { ROLE_RANK, ROLES, outranks } = require('../core/roles');

const router = express.Router();
router.use(auth, requireRole('Manager', 'Admin', 'SuperAdmin'));

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function profileFields(b, partial) {
  const opt = (v, name, o) => (partial && (v === undefined || v === null || v === '') ? undefined : str(v, name, o));
  return {
    name: opt(b.name, 'Name', { required: !partial, max: 80 }),
    email: opt(b.email, 'Email', { required: !partial, max: 120, pattern: EMAIL_RE }),
    department: opt(b.department, 'Department', { required: !partial, max: 60 }),
    role: opt(b.role, 'Role', { required: !partial, oneOf: ROLES }),
    phone: opt(b.phone, 'Phone', { max: 30 }),
    job_title: opt(b.job_title, 'Job title', { max: 80 }),
    birthday: opt(b.birthday, 'Birthday', { pattern: DATE_RE }),
    hire_date: opt(b.hire_date, 'Hire date', { pattern: DATE_RE }),
    national_id: opt(b.national_id, 'National ID', { max: 30 }),
    emergency_contact: opt(b.emergency_contact, 'Emergency contact', { max: 80 }),
    emergency_phone: opt(b.emergency_phone, 'Emergency phone', { max: 30 }),
    address: opt(b.address, 'Address', { max: 200 })
  };
}

function maybeLogPassword(line) {
  if (!config.logGeneratedPasswords) return;
  const dir = path.join(config.dirs.base, 'accounts');
  fs.mkdirSync(dir, { recursive: true });
  fs.appendFileSync(path.join(dir, `generated_passwords_${today()}.txt`), `[${eat()}] ${line}\n`);
}

const activeCount = () => db.get('SELECT COUNT(*) AS c FROM employees WHERE active=1').c;

router.get('/', (req, res) => {
  const limit = Math.min(2000, parseInt(req.query.limit, 10) || 1000);
  const offset = Math.max(0, parseInt(req.query.offset, 10) || 0);
  const q = req.query.q ? `%${String(req.query.q).slice(0, 40)}%` : null;
  const where = q ? 'WHERE name LIKE ? OR id LIKE ? OR department LIKE ? OR email LIKE ?' : '';
  const params = q ? [q, q, q, q] : [];
  const items = db.all(`SELECT id,name,email,role,department,active,tracking_number,avatar_initials,job_title,birthday,hire_date,
                               phone,created_at,last_login,login_count,locked_until_ms
                        FROM employees ${where}
                        ORDER BY CASE role WHEN 'SuperAdmin' THEN 1 WHEN 'Admin' THEN 2 WHEN 'Manager' THEN 3 WHEN 'Supervisor' THEN 4 ELSE 5 END, name
                        LIMIT ? OFFSET ?`, ...params, limit, offset);
  const total = db.get(`SELECT COUNT(*) AS c FROM employees ${where}`, ...params).c;
  res.json({ items, total, active: activeCount(), capacity: config.maxEmployees });
});

router.post('/', wrap(async (req, res) => {
  const id = str(req.body.id, 'Employee ID', { required: true, max: 24 }).toUpperCase();
  if (!ID_RE.test(id)) throw bad('Employee ID may contain only letters, digits and dashes (e.g. EMP-401).');
  const f = profileFields(req.body, false);
  if (!outranks(req.emp.role, f.role)) {
    throw forbidden(`As ${req.emp.role} you can create: ${ROLES.filter(r => ROLE_RANK[r] < ROLE_RANK[req.emp.role]).join(', ') || 'none'}.`);
  }
  if (activeCount() >= config.maxEmployees) {
    throw conflict(`Seat capacity reached (${config.maxEmployees} active employees). Disable an account or raise DDD_MAX_EMPLOYEES.`);
  }
  const supplied = String(req.body.password || '');
  if (supplied) { const p = password.policy(supplied); if (p) throw bad(p); }
  const pass = supplied || password.generate();
  const trk = tracking(f.department, id);
  try {
    db.run(`INSERT INTO employees(id,name,email,role,department,pwh,tracking_number,avatar_initials,phone,job_title,birthday,
              hire_date,national_id,emergency_contact,emergency_phone,address,created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      id, f.name, f.email.toLowerCase(), f.role, f.department, await password.hash(pass), trk, initials(f.name),
      f.phone || '', f.job_title || '', f.birthday || '', f.hire_date || '', f.national_id || '',
      f.emergency_contact || '', f.emergency_phone || '', f.address || '', now());
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) throw conflict('That Employee ID or email already exists.');
    throw e;
  }
  if (!supplied) maybeLogPassword(`NEW | ${id} | ${f.name} | ${f.role} | ${pass}`);
  audit(req.emp.id, 'USER_CREATED', `${id} — ${f.name} (${f.role})`, req.ip);
  logUserChange('CREATED', { id, name: f.name, role: f.role }, req.emp);
  presence.toSupervisors({ type: 'USER_CHANGED', action: 'created', employeeId: id, by: req.emp.name });
  res.json({ ok: true, employee_id: id, tracking_number: trk, generated_password: supplied ? undefined : pass });
}));

function loadTarget(req) {
  const id = String(req.params.id || '').toUpperCase();
  const target = db.get('SELECT * FROM employees WHERE id=?', id);
  if (!target) throw notFound('Employee not found.');
  return target;
}

router.put('/:id', wrap((req, res) => {
  const target = loadTarget(req);
  const self = target.id === req.emp.id;
  if (!self && !outranks(req.emp.role, target.role)) throw forbidden('You cannot modify an employee at or above your role level.');
  const f = profileFields(req.body, true);
  if (f.role && (self || !outranks(req.emp.role, f.role))) throw forbidden('You cannot assign that role.');
  let active;
  if (req.body.active !== undefined) {
    active = req.body.active === true || req.body.active === 1 || req.body.active === '1' ? 1 : 0;
    if (self && !active) throw bad('You cannot disable your own account.');
    if (active && !target.active && activeCount() >= config.maxEmployees) throw conflict(`Seat capacity reached (${config.maxEmployees}).`);
  }
  const sets = [], params = [];
  for (const [k, v] of Object.entries(f)) if (v !== undefined) { sets.push(`${k}=?`); params.push(k === 'email' ? v.toLowerCase() : v); }
  if (active !== undefined) { sets.push('active=?'); params.push(active); }
  if (f.name) { sets.push('avatar_initials=?'); params.push(initials(f.name)); }
  if (!sets.length) throw bad('Nothing to update.');
  try { db.run(`UPDATE employees SET ${sets.join(', ')} WHERE id=?`, ...params, target.id); }
  catch (e) { if (String(e.message).includes('UNIQUE')) throw conflict('That email already exists.'); throw e; }
  if (active === 0) kickSessions(target.id);
  audit(req.emp.id, active === 0 ? 'USER_DISABLED' : active === 1 ? 'USER_ENABLED' : 'USER_UPDATED', target.id, req.ip);
  logUserChange(active === 0 ? 'DISABLED' : active === 1 ? 'ENABLED' : 'UPDATED', target, req.emp);
  presence.toSupervisors({ type: 'USER_CHANGED', action: 'updated', employeeId: target.id, by: req.emp.name });
  res.json({ ok: true });
}));

router.delete('/:id', wrap((req, res) => {
  const target = loadTarget(req);
  if (target.id === req.emp.id) throw bad('You cannot remove your own account.');
  if (!outranks(req.emp.role, target.role)) throw forbidden(`You cannot remove an employee at or above your role level (${target.role}).`);
  const reason = str(req.body && req.body.reason, 'Reason', { max: 500 });
  kickSessions(target.id);
  const archive = archiveAndRemove(target, req.emp, reason);
  audit(req.emp.id, 'USER_DELETED', `${target.id} — ${target.name} → ${archive}`, req.ip);
  presence.toSupervisors({ type: 'USER_CHANGED', action: 'deleted', employeeId: target.id, by: req.emp.name, archive });
  res.json({ ok: true, archive });
}));

router.post('/:id/reset-password', wrap(async (req, res) => {
  const target = loadTarget(req);
  if (target.id !== req.emp.id && !outranks(req.emp.role, target.role)) throw forbidden('You cannot reset a password for an employee at or above your role.');
  const supplied = String(req.body && req.body.password || '').trim();
  if (supplied) { const p = password.policy(supplied); if (p) throw bad(p); }
  const pass = supplied || password.generate();
  db.run('UPDATE employees SET pwh=?, failed_logins=0, locked_until_ms=0 WHERE id=?', await password.hash(pass), target.id);
  if (target.id !== req.emp.id) kickSessions(target.id);
  if (!supplied) maybeLogPassword(`RESET by ${req.emp.id} | ${target.id} | ${pass}`);
  audit(req.emp.id, 'PASSWORD_RESET', target.id, req.ip);
  res.json({ ok: true, generated_password: supplied ? undefined : pass });
}));

router.post('/:id/unlock', wrap((req, res) => {
  const target = loadTarget(req);
  db.run('UPDATE employees SET failed_logins=0, locked_until_ms=0 WHERE id=?', target.id);
  audit(req.emp.id, 'ACCOUNT_UNLOCKED', target.id, req.ip);
  res.json({ ok: true });
}));

module.exports = router;
