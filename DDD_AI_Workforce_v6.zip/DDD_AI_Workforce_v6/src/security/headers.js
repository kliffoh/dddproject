'use strict';
/** Security headers + strict CORS (v5 reflected ANY origin with credentials). */
const config = require('../config');

function securityHeaders(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com data:",
    "img-src 'self' data: blob:",
    "connect-src 'self' ws: wss:",
    "frame-ancestors 'none'",
    "base-uri 'self'",
    "form-action 'self'"
  ].join('; '));
  if (req.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
}

function originAllowed(origin, req) {
  if (!origin) return true;
  const o = origin.replace(/\/+$/, '');
  if (config.allowedOrigins.includes(o)) return true;
  if (config.publicUrl && o === config.publicUrl) return true;
  try { return new URL(o).host === req.headers.host; } catch (_) { return false; }
}

function cors(req, res, next) {
  const origin = req.headers.origin;
  if (origin && originAllowed(origin, req)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type,X-DDD-Session');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
    res.setHeader('Access-Control-Max-Age', '600');
  } else if (origin && req.path.startsWith('/api/')) {
    return res.status(403).json({ error: 'Origin not allowed. Add it to ALLOWED_ORIGINS.' });
  }
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
}

module.exports = { securityHeaders, cors, originAllowed };
