'use strict';
/**
 * Database-backed sessions with an in-memory read-through cache.
 *
 * • Only the SHA-256 of the token is stored — a leaked database cannot be
 *   replayed as live sessions.
 * • Sessions survive restarts and deployments (v5 kept them in a Map, so every
 *   restart logged out the entire workforce).
 * • last_seen is written at most once a minute per session to keep write
 *   amplification low with hundreds of active users.
 */
const crypto = require('crypto');
const db = require('../db/database');
const config = require('../config');

const cache = new Map();                 // hash -> { empId, expires, lastWrite }
const sha = (t) => crypto.createHash('sha256').update(String(t)).digest('hex');

function create(empId, ip = '', ua = '') {
  const token = crypto.randomBytes(32).toString('base64url');
  const h = sha(token), t = Date.now(), expires = t + config.sessionTtlMs;
  db.run('INSERT INTO sessions(token_hash,employee_id,created_ms,last_seen_ms,expires_ms,ip,user_agent) VALUES(?,?,?,?,?,?,?)',
    h, empId, t, t, expires, String(ip).slice(0, 64), String(ua).slice(0, 200));
  cache.set(h, { empId, expires, lastWrite: t });
  return token;
}

/** @returns {string|null} employee id */
function resolve(token) {
  if (!token || typeof token !== 'string' || token.length > 128) return null;
  const h = sha(token), t = Date.now();
  let s = cache.get(h);
  if (!s) {
    const row = db.get('SELECT employee_id, expires_ms, last_seen_ms FROM sessions WHERE token_hash=?', h);
    if (!row) return null;
    s = { empId: row.employee_id, expires: row.expires_ms, lastWrite: row.last_seen_ms };
    cache.set(h, s);
  }
  if (s.expires < t) { destroy(token); return null; }
  if (t - s.lastWrite > 60000) { s.lastWrite = t; db.run('UPDATE sessions SET last_seen_ms=? WHERE token_hash=?', t, h); }
  return s.empId;
}

function destroy(token) { const h = sha(token); cache.delete(h); db.run('DELETE FROM sessions WHERE token_hash=?', h); }

function destroyAllFor(empId, exceptToken = null) {
  const keep = exceptToken ? sha(exceptToken) : null;
  for (const [h, s] of cache) if (s.empId === empId && h !== keep) cache.delete(h);
  if (keep) db.run('DELETE FROM sessions WHERE employee_id=? AND token_hash<>?', empId, keep);
  else db.run('DELETE FROM sessions WHERE employee_id=?', empId);
}

function sweep() {
  const t = Date.now();
  for (const [h, s] of cache) if (s.expires < t) cache.delete(h);
  return db.run('DELETE FROM sessions WHERE expires_ms < ?', t).changes;
}

const count = () => db.get('SELECT COUNT(*) AS c FROM sessions WHERE expires_ms > ?', Date.now()).c;

module.exports = { create, resolve, destroy, destroyAllFor, sweep, count };
