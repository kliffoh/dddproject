'use strict';
/**
 * Password hashing.
 *
 * New hashes use scrypt from Node's crypto module. It runs on libuv's thread
 * pool, so 550 people signing in at 08:00 do not freeze the event loop (the
 * v5 bcrypt.hashSync / compareSync calls blocked ~70 ms each on the main thread).
 *
 * Legacy bcrypt hashes from v4/v5 are still verified, then transparently
 * re-hashed with scrypt on the next successful login ("rehash on verify").
 */
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const N = 16384, r = 8, p = 1, KEYLEN = 64;

const scrypt = (pw, salt) => new Promise((resolve, reject) =>
  crypto.scrypt(pw, salt, KEYLEN, { N, r, p, maxmem: 64 * 1024 * 1024 }, (e, k) => (e ? reject(e) : resolve(k))));

async function hash(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(String(password), salt);
  return `scrypt$${N}$${r}$${p}$${salt.toString('base64')}$${key.toString('base64')}`;
}

/** @returns {Promise<{ok:boolean, needsRehash:boolean}>} */
async function verify(password, stored) {
  if (!stored) return { ok: false, needsRehash: false };
  if (stored.startsWith('scrypt$')) {
    const [, , , , saltB64, keyB64] = stored.split('$');
    const key = await scrypt(String(password), Buffer.from(saltB64, 'base64'));
    const expected = Buffer.from(keyB64, 'base64');
    const ok = key.length === expected.length && crypto.timingSafeEqual(key, expected);
    return { ok, needsRehash: false };
  }
  if (stored.startsWith('$2')) {                       // legacy bcrypt
    const ok = await bcrypt.compare(String(password), stored);
    return { ok, needsRehash: ok };
  }
  return { ok: false, needsRehash: false };
}

/** Readable random password: 12 chars, no ambiguous glyphs, always mixed classes. */
function generate() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ', a = 'abcdefghijkmnpqrstuvwxyz', d = '23456789', s = '!@#$%*?';
  const all = A + a + d;
  const pick = (set) => set[crypto.randomInt(set.length)];
  const chars = [pick(A), pick(a), pick(d), pick(s)];
  while (chars.length < 12) chars.push(pick(all));
  for (let i = chars.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [chars[i], chars[j]] = [chars[j], chars[i]]; }
  return chars.join('');
}

function policy(pw) {
  pw = String(pw || '');
  if (pw.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Password must contain letters and numbers.';
  return null;
}

module.exports = { hash, verify, generate, policy };
