'use strict';
/**
 * Token-bucket rate limiter (in-memory, O(1) per request).
 *
 * Note for a real office: all 550 employees may share ONE public IP behind the
 * office NAT, so per-IP limits must be generous. Brute-force protection is
 * therefore primarily per-ACCOUNT (lockout in the auth route), with the per-IP
 * bucket acting only as a flood guard.
 */
function limiter({ capacity, refillPerSec, key }) {
  const buckets = new Map();
  setInterval(() => {                      // evict idle buckets
    const t = Date.now();
    for (const [k, b] of buckets) if (t - b.ts > 10 * 60 * 1000) buckets.delete(k);
  }, 60 * 1000).unref();

  return (req, res, next) => {
    const k = key(req);
    const t = Date.now();
    let b = buckets.get(k);
    if (!b) { b = { tokens: capacity, ts: t }; buckets.set(k, b); }
    b.tokens = Math.min(capacity, b.tokens + ((t - b.ts) / 1000) * refillPerSec);
    b.ts = t;
    if (b.tokens < 1) {
      const wait = Math.ceil((1 - b.tokens) / refillPerSec);
      res.setHeader('Retry-After', String(wait));
      return res.status(429).json({ error: `Too many requests. Please wait ${wait}s and try again.` });
    }
    b.tokens -= 1;
    next();
  };
}

module.exports = { limiter };
