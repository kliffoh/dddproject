'use strict';
/**
 * SQLite access layer (node:sqlite, built into Node 22 — no native build step).
 *
 * Design notes
 * ─────────────
 * • WAL journal: readers never block the single writer, which is the access
 *   pattern of a workforce system (many dashboard reads, small writes).
 * • Prepared-statement cache: SQL is compiled once and reused. Re-preparing on
 *   every request (the v5 behaviour) costs far more than executing the query.
 * • All DB calls are synchronous. Inside one route handler there is therefore
 *   no interleaving between "read state" and "write state" — Node's event loop
 *   gives us serialisability for free, so double-clicks cannot create two
 *   work sessions.
 */
const fs   = require('fs');
const path = require('path');
const config = require('../config');

let DatabaseSync;
try { ({ DatabaseSync } = require('node:sqlite')); }
catch (_) {
  console.error('\n[FATAL] node:sqlite is unavailable. Install Node.js 22.13 or newer: https://nodejs.org\n');
  process.exit(1);
}

fs.mkdirSync(config.dirs.db, { recursive: true });
const DB_PATH = path.join(config.dirs.db, 'ddd.sqlite3');

const raw = new DatabaseSync(DB_PATH);
raw.exec('PRAGMA journal_mode = WAL');
raw.exec('PRAGMA synchronous = NORMAL');
raw.exec('PRAGMA foreign_keys = ON');
raw.exec('PRAGMA busy_timeout = 5000');
raw.exec('PRAGMA temp_store = MEMORY');
raw.exec('PRAGMA cache_size = -32000');      // ~32 MB page cache

const cache = new Map();
function stmt(sql) {
  let s = cache.get(sql);
  if (!s) { s = raw.prepare(sql); cache.set(sql, s); }
  return s;
}

const num = (r) => ({ changes: Number(r.changes), lastInsertRowid: Number(r.lastInsertRowid) });

const db = {
  path: DB_PATH,
  exec: (sql) => raw.exec(sql),
  get:  (sql, ...p) => stmt(sql).get(...p),
  all:  (sql, ...p) => stmt(sql).all(...p),
  run:  (sql, ...p) => num(stmt(sql).run(...p)),
  /** Run fn inside BEGIN IMMEDIATE … COMMIT; rolls back on throw. */
  tx(fn) {
    raw.exec('BEGIN IMMEDIATE');
    try { const out = fn(); raw.exec('COMMIT'); return out; }
    catch (e) { try { raw.exec('ROLLBACK'); } catch (_) {} throw e; }
  },
  columns: (table) => raw.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name),
  backupTo(file) { raw.prepare('VACUUM INTO ?').run(file); },
  close() { cache.clear(); try { raw.exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {} raw.close(); }
};

module.exports = db;
