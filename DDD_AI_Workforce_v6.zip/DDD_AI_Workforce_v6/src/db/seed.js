'use strict';
/**
 * Seeding runs ONLY on an empty database.
 * v5 re-applied the demo passwords on every boot (INSERT … ON CONFLICT UPDATE pwh),
 * which silently reverted any password an administrator had changed.
 * Recovery of the developer account is now an explicit, opt-in action:
 * set SUPER_ADMIN_PASS and restart.
 */
const db = require('./database');
const config = require('../config');
const password = require('../security/password');
const log = require('../core/logger');
const { now } = require('../core/time');

const initials = (name) => name.split(/\s+/).map(w => w[0] || '').join('').substring(0, 2).toUpperCase();
const tracking = (dept, id) => `TRK-${new Date().getFullYear()}-${dept.substring(0, 4).toUpperCase()}-${id}`;

const DEMO = [
  { id: 'EMP-312', name: 'Sarah Jenkins',  email: 'sarah@ddd.local',   role: 'Employee',   dept: 'Production',     pass: 'sarah123',      title: 'Data Entry Specialist' },
  { id: 'SUP-101', name: 'Michael Otieno', email: 'michael@ddd.local', role: 'Supervisor', dept: 'Production',     pass: 'supervisor123', title: 'Production Supervisor' },
  { id: 'MGR-001', name: 'Grace Mwangi',   email: 'grace@ddd.local',   role: 'Manager',    dept: 'Operations',     pass: 'manager123',    title: 'Operations Manager' },
  { id: 'ADM-001', name: 'DDD Admin',      email: 'admin@ddd.local',   role: 'Admin',      dept: 'Administration', pass: 'admin123',      title: 'System Administrator' }
];

const NOTES = [
  ['Annual Leave Policy', 'Leave', 'All employees are entitled to 21 days of annual leave per year. Requests must be submitted at least 7 days in advance. Unused leave may be carried forward (up to 10 days) with manager approval.', 'multi'],
  ['Break Policy', 'HR', 'The standard working day is 9 hours: 8 hours of active work and 1 hour for breaks. Two 15-minute tea breaks and one 30-minute lunch break are standard.', 'multi'],
  ['Shift Hours', 'HR', 'The standard shift is 08:00 to 17:00 East Africa Time (EAT). Overtime begins after 8 active hours and requires supervisor pre-approval.', 'multi'],
  ['Maternity & Paternity Leave', 'Leave', 'Maternity leave is 90 days as per the Kenya Employment Act. Paternity leave is 14 days. Supporting documents are required.', 'multi'],
  ['Sick Leave', 'Leave', 'Sick leave requires a medical certificate from a registered practitioner for absences longer than one day. Notify your supervisor before the start of your shift.', 'multi'],
  ['System & Account Help', 'Tech', 'For login issues or password resets, contact your IT administrator or visit the reception desk. You can change your own password under Settings.', 'multi'],
  ['Statutory Deductions', 'Welfare', 'Permanent employees are enrolled in SHA/SHIF (which replaced NHIF), NSSF and the Affordable Housing Levy. Contributions are deducted monthly through payroll. HR can confirm current rates.', 'multi'],
  ['Overtime Policy', 'HR', 'Overtime is calculated on active work hours exceeding 8 hours per day. The rate is 1.5x on weekdays and 2x on weekends and public holidays.', 'multi'],
  ['Payslips & Salary', 'Payroll', 'Salaries are paid by the last working day of each month. Payslips are issued by HR; contact the HR desk at reception for copies or corrections.', 'multi'],
  ['Grievance Procedure', 'Policy', 'DDD has a zero-tolerance policy on harassment. All grievances should be reported to HR in writing. Anonymous concerns can go via the reception suggestion box.', 'multi'],
  ['Likizo ya Mwaka', 'Leave', 'Wafanyakazi wote wanastahili siku 21 za likizo ya mwaka kwa mwaka. Maombi yanapaswa kuwasilishwa siku 7 kabla.', 'sw'],
  ['Saa za Kazi', 'HR', 'Muda wa kawaida wa kazi ni saa 08:00 hadi 17:00 kwa Saa za Afrika Mashariki (EAT). Kuna saa 1 ya mapumziko.', 'sw']
];

async function insertEmployee(a) {
  db.run(`INSERT INTO employees (id,name,email,role,department,pwh,tracking_number,avatar_initials,job_title,hire_date,created_at)
          VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    a.id, a.name, a.email, a.role, a.dept, await password.hash(a.pass),
    a.trk || tracking(a.dept, a.id), a.av || initials(a.name), a.title, '2020-01-01', now());
}

async function seed() {
  const count = db.get('SELECT COUNT(*) AS c FROM employees').c;

  if (count === 0 && config.seedDemo) {
    for (const a of DEMO) await insertEmployee(a);
    log.info('Seeded demo accounts (fresh database). Change these passwords before going live.');
  }

  // The developer / SuperAdmin account must always exist.
  const dev = db.get('SELECT id FROM employees WHERE id=?', config.superId);
  if (!dev) {
    const pass = config.superPassOverride || 'DDD@SuperDev2026!';
    await insertEmployee({ id: config.superId, name: 'Clive Otieno', email: 'dev@ddd.local', role: 'SuperAdmin',
      dept: 'Technology', pass, title: 'The Anonymous Developer', trk: 'ANONYMOUS', av: '🎭' });
    log.info(`Created SuperAdmin ${config.superId}.`);
  } else if (config.superPassOverride) {
    db.run('UPDATE employees SET pwh=?, active=1, failed_logins=0, locked_until_ms=0 WHERE id=?',
      await password.hash(config.superPassOverride), config.superId);
    log.info(`SuperAdmin ${config.superId} password re-applied from SUPER_ADMIN_PASS.`);
  }

  if (db.get('SELECT COUNT(*) AS c FROM chatbot_notes').c === 0) {
    for (const n of NOTES) {
      db.run('INSERT INTO chatbot_notes(title,content,category,language,created_by,created_at) VALUES(?,?,?,?,?,?)',
        n[0], n[2], n[1], n[3], config.superId, now());
    }
  }
}

module.exports = { seed, initials, tracking };
