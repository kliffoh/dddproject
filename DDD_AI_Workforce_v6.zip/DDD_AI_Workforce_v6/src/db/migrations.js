'use strict';
/**
 * Versioned, forward-only, NON-DESTRUCTIVE migrations.
 *
 * v5 dropped every table whenever PRAGMA user_version differed from the code's
 * SCHEMA constant — i.e. a routine upgrade erased all attendance history.
 * Here each migration is additive (CREATE IF NOT EXISTS / ADD COLUMN) and runs
 * exactly once inside a transaction. Databases created by v4/v5 (user_version
 * 1..6) are upgraded in place; no data is ever dropped.
 */
const db  = require('./database');
const log = require('../core/logger');

function ensureColumn(table, column, ddl) {
  if (!db.columns(table).includes(column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${ddl}`);
}

const MIGRATIONS = [
  {
    version: 6,
    name: 'baseline (v5-compatible tables)',
    up() {
      db.exec(`
        CREATE TABLE IF NOT EXISTS employees (
          id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
          role TEXT NOT NULL DEFAULT 'Employee', department TEXT NOT NULL,
          pwh TEXT NOT NULL, active INTEGER DEFAULT 1,
          tracking_number TEXT, avatar_initials TEXT,
          created_at TEXT NOT NULL, last_login TEXT);
        CREATE TABLE IF NOT EXISTS attendance (
          id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL,
          work_date TEXT NOT NULL, login_time TEXT, logout_time TEXT,
          status TEXT DEFAULT 'Present', UNIQUE(employee_id, work_date));
        CREATE TABLE IF NOT EXISTS work_sessions (
          id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL,
          work_date TEXT NOT NULL, started_at TEXT, ended_at TEXT,
          active_seconds INTEGER DEFAULT 0, break_seconds INTEGER DEFAULT 0,
          overtime_seconds INTEGER DEFAULT 0, status TEXT DEFAULT 'IDLE');
        CREATE TABLE IF NOT EXISTS breaks (
          id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL,
          started_at TEXT NOT NULL, ended_at TEXT, duration_seconds INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS leave_requests (
          id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL,
          request_type TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL,
          reason TEXT NOT NULL, status TEXT DEFAULT 'Pending',
          submitted_at TEXT NOT NULL, reviewed_by TEXT, reviewed_at TEXT);
        CREATE TABLE IF NOT EXISTS chat_queries (
          id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL,
          query TEXT NOT NULL, response TEXT NOT NULL,
          intent TEXT DEFAULT 'general', confidence TEXT DEFAULT 'medium',
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS chatbot_notes (
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          content TEXT NOT NULL, category TEXT DEFAULT 'General',
          created_by TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit_log (
          id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id TEXT NOT NULL,
          action TEXT NOT NULL, details TEXT DEFAULT '',
          ip_address TEXT DEFAULT '', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS inactivity_alerts (
          id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL,
          alert_time TEXT NOT NULL, duration_minutes INTEGER NOT NULL,
          acknowledged INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS chat_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL,
          role TEXT NOT NULL, content TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS user_change_log (
          id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL,
          target_id TEXT NOT NULL, target_name TEXT, actor_id TEXT NOT NULL,
          actor_name TEXT, actor_role TEXT, archive_file TEXT,
          reason TEXT DEFAULT '', created_at TEXT NOT NULL);
      `);
      // Columns that older (v4) databases may be missing
      for (const [c, d] of [['phone', "TEXT DEFAULT ''"], ['job_title', "TEXT DEFAULT ''"],
        ['birthday', "TEXT DEFAULT ''"], ['hire_date', "TEXT DEFAULT ''"], ['national_id', "TEXT DEFAULT ''"]]) {
        ensureColumn('employees', c, d);
      }
      ensureColumn('chat_queries', 'language', "TEXT DEFAULT 'en'");
      ensureColumn('chat_queries', 'keywords', "TEXT DEFAULT ''");
      ensureColumn('chatbot_notes', 'language', "TEXT DEFAULT 'multi'");
    }
  },
  {
    version: 7,
    name: 'v6 production: persistent sessions, ML feedback, indexes, lockout',
    up() {
      db.exec(`
        CREATE TABLE IF NOT EXISTS sessions (
          token_hash TEXT PRIMARY KEY, employee_id TEXT NOT NULL,
          created_ms INTEGER NOT NULL, last_seen_ms INTEGER NOT NULL,
          expires_ms INTEGER NOT NULL, ip TEXT DEFAULT '', user_agent TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS note_stats (
          note_id INTEGER PRIMARY KEY, served INTEGER DEFAULT 0,
          helpful INTEGER DEFAULT 0, unhelpful INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS intent_training (
          id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL,
          intent TEXT NOT NULL, source TEXT DEFAULT 'feedback', created_at TEXT NOT NULL);

        CREATE INDEX IF NOT EXISTS ix_sessions_emp       ON sessions(employee_id);
        CREATE INDEX IF NOT EXISTS ix_sessions_exp       ON sessions(expires_ms);
        CREATE INDEX IF NOT EXISTS ix_att_date           ON attendance(work_date);
        CREATE INDEX IF NOT EXISTS ix_ws_emp_date        ON work_sessions(employee_id, work_date);
        CREATE INDEX IF NOT EXISTS ix_ws_date            ON work_sessions(work_date);
        CREATE INDEX IF NOT EXISTS ix_breaks_session     ON breaks(session_id);
        CREATE INDEX IF NOT EXISTS ix_leave_emp          ON leave_requests(employee_id);
        CREATE INDEX IF NOT EXISTS ix_leave_status       ON leave_requests(status);
        CREATE INDEX IF NOT EXISTS ix_cq_created         ON chat_queries(created_at);
        CREATE INDEX IF NOT EXISTS ix_cq_emp             ON chat_queries(employee_id);
        CREATE INDEX IF NOT EXISTS ix_ch_emp             ON chat_history(employee_id, id);
        CREATE INDEX IF NOT EXISTS ix_ch_created         ON chat_history(created_at);
        CREATE INDEX IF NOT EXISTS ix_alerts_ack         ON inactivity_alerts(acknowledged);
        CREATE INDEX IF NOT EXISTS ix_audit_created      ON audit_log(created_at);
        CREATE INDEX IF NOT EXISTS ix_emp_active_role    ON employees(active, role);
      `);
      ensureColumn('employees', 'failed_logins', 'INTEGER DEFAULT 0');
      ensureColumn('employees', 'locked_until_ms', 'INTEGER DEFAULT 0');
      ensureColumn('employees', 'emergency_contact', "TEXT DEFAULT ''");
      ensureColumn('employees', 'emergency_phone', "TEXT DEFAULT ''");
      ensureColumn('employees', 'address', "TEXT DEFAULT ''");
      ensureColumn('employees', 'login_count', 'INTEGER DEFAULT 0');
      ensureColumn('chat_queries', 'feedback', 'INTEGER');
      ensureColumn('chat_queries', 'sources', "TEXT DEFAULT ''");
      ensureColumn('chat_queries', 'score', 'REAL DEFAULT 0');
      ensureColumn('chat_queries', 'resolved', 'INTEGER DEFAULT 0');
    }
  }
];

const LATEST = MIGRATIONS[MIGRATIONS.length - 1].version;

function migrate() {
  const current = Number(db.get('PRAGMA user_version').user_version || 0);
  if (current > LATEST) {
    log.info(`Database schema v${current} is newer than this build (v${LATEST}); continuing read-compatible.`);
    return;
  }
  for (const m of MIGRATIONS) {
    // v1..v5 databases still run the baseline: every statement is idempotent.
    if (m.version <= current) continue;
    db.tx(() => { m.up(); db.exec(`PRAGMA user_version = ${m.version}`); });
    log.info(`Migration v${m.version} applied — ${m.name}`);
  }
}

module.exports = { migrate, LATEST };
