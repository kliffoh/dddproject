#!/bin/sh
# Cloud volumes (Fly, Render, Railway) are usually mounted root-owned.
# Fix ownership once, then drop privileges to the unprivileged "node" user.
set -e
if [ "$(id -u)" = "0" ]; then
  chown -R node:node "${DDD_DATA_DIR:-/data}" 2>/dev/null || true
  exec setpriv --reuid=node --regid=node --init-groups "$@"
fi
exec "$@"
