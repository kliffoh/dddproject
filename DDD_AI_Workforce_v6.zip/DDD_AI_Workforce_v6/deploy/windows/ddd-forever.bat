@echo off
:: DDD watchdog — restarts the server whenever it stops. Launched at boot/logon by
:: the scheduled task that DDD_HOSTING.bat (option 9) creates.
setlocal
cd /d "%~dp0..\.."
set "LOG=%CD%\ddd-forever.log"
:loop
for %%A in ("%LOG%") do if %%~zA GTR 10485760 del "%LOG%" >nul 2>&1
echo [%date% %time%] Starting DDD server >> "%LOG%"
node server.js >> "%LOG%" 2>&1
echo [%date% %time%] Server exited with code %errorlevel% - restarting in 5 seconds >> "%LOG%"
timeout /t 5 /nobreak >nul
goto loop
