// PM2 process definition — keeps DDD running, restarts on crash, survives reboots (pm2 startup).
// One instance on purpose: live presence and rate limits live in memory and SQLite has a single
// writer, so a cluster would split state. One Node process comfortably serves 550 employees.
const path = require('path');
module.exports = {
  apps: [{
    name: 'ddd-workforce',
    script: 'server.js',
    cwd: path.resolve(__dirname, '..'),
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    min_uptime: '20s',
    max_restarts: 1000,
    exp_backoff_restart_delay: 500,
    max_memory_restart: '800M',
    kill_timeout: 12000,
    time: true,
    env: { NODE_ENV: 'production' }
  }]
};
